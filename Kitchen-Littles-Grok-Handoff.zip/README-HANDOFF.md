# Kitchen Littles — portable handoff

This package continues an existing project; it is not a finished published revision.

Start with GROK-PROMPT.txt. The gameplay and desktop shell have been written, but the original approved purple window image must be reattached before production integration. No kitchen sounds have been supplied. The included Casey’s Room HTML is the unchanged published baseline, not a version already containing the kitchen.

## Included

- Caseys-Room-with-Mood-Ring.html: unchanged full baseline containing the existing independent programs.
- Kitchen-Littles-Gameplay-Preview.html: frameless development preview of the working kitchen, not the approved final window.
- program/: editable JS/CSS, desktop shell, portable builder/integration scripts, atlas metadata and WebP artwork sheets, test code/results and implementation checkpoint.
- PLAN.json: all 98 catalogue entries, quantities, scales, storage and recipe relationships.
- FOOD-ACCOUNTING.md: accounting by supplied reference set.
- ITEMS-AND-SOUNDS.md / CSV and SOUND-CUES.csv: working item list and blank sound mappings.
- KITCHEN-PLAN.md and AGENTS.md: design and canonical delivery rules.

## Build

From the unpacked directory, run `python program/build-program.py`. It rebuilds the embedded program and a private `program/harness.html` from the editable sources and included WebP sheets. Existing PNG originals and original user reference photos are not required to rebuild this version; they are not included.

Supply the exact approved frame, inspect it, then make `program/frame-config.json` using the schema in program/IMPLEMENTATION.md. Set path relative to program/ or use an absolute local path; approved_original must be true. `python program/integrate.py` then appends the kitchen block to the baseline. It refuses to run without the approved frame.

No substitute frame has been generated. Core playthrough tests passed, and desktop lifecycle tests passed using an invisible geometry fixture only. The actual approved-frame integration still needs visual testing.

For sound files, add only the clips the user supplies to the existing sound routing and embed them for offline use. Preserve the kitchen storage key and all other programs.

If moving the project into a real checkout, use its repository root for the canonical file and follow AGENTS.md. This archive does not contain Git credentials or a .git directory.
