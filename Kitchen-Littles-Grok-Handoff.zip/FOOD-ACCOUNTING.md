# Reference-set accounting

All 98 catalogue entries are accounted for below. Reused items point to the same inventory object. Alternate views and drink fills are states. Multiquantity rows retain their explicit piece counts.

Cutlery drawer: pink knife/fork/spoon and turquoise knife. Cooking/serving drawer: slotted spatula, both cooking/serving spoons, cake server, pizza wheel and scooper. Both drawers share the global storage rule.

## Fixed appliances

- Side-by-side fridge with ice dispenser × 1 — Fixed appliance
- Four-burner stove and oven × 1 — Fixed appliance
- Metal floral toaster × 1 — Fixed appliance
- Metal floral blender × 1 — Fixed appliance
- Pink crank popcorn machine × 1 — Fixed appliance
- Yellow can opener × 1 — Fixed appliance

## Toaster Fun

- Partly wrapped Wonder toy loaf × 1 — Breakfast pantry
- Plain butter-coloured toaster toast pieces × 2 — Breakfast pantry
- Large rose-and-heart dinner plate × 1 — Dish cupboard
- Turquoise-handled knife from Toaster Fun × 1 — Cutlery drawer
- Red / white / blue MILK carton × 1 — Fridge / freezer
- Tropicana orange juice carton × 1 — Fridge / freezer

## Turkey dinner

- Molded whole turkey × 1 — Fridge / freezer
- Oval metal turkey roasting pan × 1 — Baking / serving cupboard

## Ice Cream Shakes

- Open Dreyer’s Grand ice-cream tub × 1 — Fridge / freezer
- Striped Dreyer’s tub lid × 1 — Fridge / freezer
- White ice-cream scoop balls × 3 — Fridge / freezer
- Turquoise-handled ice-cream scooper × 1 — Cooking / serving tools drawer
- Tall milkshake with foam and bent white straw × 1 — Dish cupboard
- Red / white / blue MILK carton × 1 — Fridge / freezer
- Metal floral blender × 1 — Fixed appliance

## Popcorn set

- Pink crank popcorn machine × 1 — Fixed appliance
- Turquoise floral-rim popcorn bowl × 1 — Dish cupboard
- Molded yellow-and-ivory serving popcorn insert × 1 — Canned-food cupboard
- Flat POP CORN packet × 1 — Canned-food cupboard

## Dinnerware, one of each

- Large rose-and-heart dinner plate × 1 — Dish cupboard
- Small rose-and-heart side plate × 1 — Dish cupboard
- Rose-patterned bowl × 1 — Dish cupboard
- Coral / pink mug × 1 — Dish cupboard
- Clear drinking tumbler × 1 — Dish cupboard
- Pink-handled table knife × 1 — Cutlery drawer
- Pink-handled table fork × 1 — Cutlery drawer
- Pink-handled table spoon × 1 — Cutlery drawer

## Birthday Party

- Pink / purple iced birthday cake and removable slice × 1 — Fridge / freezer
- White cake pedestal stand × 1 — Baking / serving cupboard
- Pink-handled cake server with turquoise collar × 1 — Cooking / serving tools drawer
- Small green-ring floral birthday plate × 1 — Dish cupboard
- Large green-ring floral birthday serving plate × 1 — Dish cupboard
- Red / white / blue MILK carton × 1 — Fridge / freezer
- Clear drinking tumbler × 1 — Dish cupboard
- Pink-handled table fork × 1 — Cutlery drawer
- Pink-handled table spoon × 1 — Cutlery drawer

## Freezer Fun

- Ice-cream sandwiches × 2 — Fridge / freezer
- Blue Ice Cream Sandwiches box × 1 — Fridge / freezer
- Round frozen waffles × 2 — Fridge / freezer
- Frozen Waffles box × 1 — Fridge / freezer
- Striped push-up ice pops × 3 — Fridge / freezer
- Push-Up ice-pop box × 1 — Fridge / freezer
- Oval divided frozen-dinner tray × 1 — Fridge / freezer
- Hungry-Man frozen-dinner box × 1 — Fridge / freezer

## Italian

- Round molded salad insert × 1 — Fridge / freezer
- Folded green vegetable insert × 1 — Fridge / freezer
- Small whole Italian-pack pizza × 1 — Fridge / freezer
- Spaghetti disk with red sauce and three meatballs × 1 — Fridge / freezer
- Whole molded red tomato × 1 — Fridge / freezer
- Molded Italian loaf × 1 — Breakfast pantry
- Printed ITALIAN bread wrapper × 1 — Breakfast pantry
- Three-colour ICE CREAM brick carton × 1 — Fridge / freezer

## Pasta Fun

- Green-handled Pasta Fun pot × 1 — Cooking cupboard
- Red-knob silver Pasta Fun lid × 1 — Cooking cupboard
- Green-handled Pasta Fun serving spoon × 1 — Cooking / serving tools drawer
- Brown COLA bottle with red label and white cap × 1 — Fridge / freezer
- Spaghetti disk with red sauce and three meatballs × 1 — Fridge / freezer
- Molded Italian loaf × 1 — Breakfast pantry
- Printed ITALIAN bread wrapper × 1 — Breakfast pantry
- Three-colour ICE CREAM brick carton × 1 — Fridge / freezer

## Cookware, reuse existing turkey roaster

- Small pink-handled round frying pan × 1 — Cooking cupboard
- Large pink-handled round frying pan × 1 — Cooking cupboard
- Pink-handled square griddle × 1 — Cooking cupboard
- Small pink-handled saucepan × 1 — Cooking cupboard
- Small pink-knob saucepan lid × 1 — Cooking cupboard
- Large pink-handled saucepan × 1 — Cooking cupboard
- Large pink-knob saucepan lid × 1 — Cooking cupboard
- Pink-handled metal cooking spoon × 1 — Cooking / serving tools drawer
- Pink-handled slotted spatula × 1 — Cooking / serving tools drawer
- Oval metal turkey roasting pan × 1 — Baking / serving cupboard

## Breakfast variants

- One joined double-fried-egg piece × 1 — Fridge / freezer
- One joined wavy bacon piece × 1 — Fridge / freezer
- Pink grapefruit half with red centre nub × 1 — Fridge / freezer
- Syrup-and-butter pancakes × 2 — Fridge / freezer
- Syrup-and-butter triangular French toast × 2 — Fridge / freezer
- Kellogg’s Corn Flakes cereal box × 1 — Breakfast pantry
- Fruity-O’s cereal box × 1 — Breakfast pantry
- Purple grape jam jar with white lid × 1 — Breakfast pantry
- Thin Sliced Bacon packet × 1 — Fridge / freezer
- Yellow AAA LARGE EGGS carton × 1 — Fridge / freezer
- Loose white toy egg × 1 — Fridge / freezer
- Partly wrapped Wonder toy loaf × 1 — Breakfast pantry
- Red / white / blue MILK carton × 1 — Fridge / freezer
- Tropicana orange juice carton × 1 — Fridge / freezer
- Large rose-and-heart dinner plate × 1 — Dish cupboard
- Rose-patterned bowl × 1 — Dish cupboard

## Can opener and food cans

- Yellow can opener × 1 — Fixed appliance
- Del Monte Peach Halves can × 1 — Canned-food cupboard
- Peach can silver lid with white plug × 1 — Canned-food cupboard
- Franco-American SpaghettiOs can × 1 — Canned-food cupboard
- SpaghettiOs can silver lid with red-brown plug × 1 — Canned-food cupboard
- Del Monte Whole Kernel Corn can × 1 — Canned-food cupboard
- Corn can silver lid with ochre plug × 1 — Canned-food cupboard

## Pizza Party

- Pizza Party quarter slices × 4 — Fridge / freezer
- Round metal pizza tray × 1 — Baking / serving cupboard
- Green-handled silver pizza wheel × 1 — Cooking / serving tools drawer
- Red-and-green-ring Pasta plate × 1 — Dish cupboard
- White / red / green PIZZA box × 1 — Canned-food cupboard
- Red COLA can with repeated white lettering × 1 — Fridge / freezer
- Clear drinking tumbler × 1 — Dish cupboard

## Cookout additions

- Complete hot dog in bun with mustard stripe × 1 — Fridge / freezer
- Complete hamburger with tomato and lettuce × 1 — Fridge / freezer
- David’s Franks packet × 1 — Fridge / freezer
- Yellow corn on the cob × 1 — Fridge / freezer

## Picnic

- Red toy apple × 1 — Fridge / freezer
- Green toy apple × 1 — Fridge / freezer
- Hunt’s ketchup bottle × 1 — Fridge / freezer
- Yellow mustard bottle with red cap × 1 — Fridge / freezer
- Green Lemon Lime soda bottle × 1 — Fridge / freezer
- Complete white-bread picnic sandwich × 1 — Fridge / freezer
- Golden-brown chicken drumsticks × 2 — Fridge / freezer
- Red / yellow Potato Chips bag × 1 — Canned-food cupboard
- Partly wrapped Wonder toy loaf × 1 — Breakfast pantry

## Glass states

- Clear drinking tumbler × 1 — Dish cupboard
- Red / white / blue MILK carton × 1 — Fridge / freezer
- Tropicana orange juice carton × 1 — Fridge / freezer
- Red COLA can with repeated white lettering × 1 — Fridge / freezer
- Brown COLA bottle with red label and white cap × 1 — Fridge / freezer
- Green Lemon Lime soda bottle × 1 — Fridge / freezer

## Parts and exclusions

- Cake has one whole-cake identity with four conserved serving segments. Pizza Party is four quarter pieces; the smaller Italian pizza stays separate.
- White balls enclosed in the crank machine are mechanism parts; the separate serving popcorn insert is edible pretend-food artwork.
- One shared drinking tumbler has empty, milk, orange, cola and ice states. The tall milkshake has its own vessel.
- No duplicate turkey pan, repeated milk/OJ cartons, repeated Wonder loaf, or repeated dinnerware from other packs.
- Cans include their removable lids; the references show empty toy cans, so loose canned contents are not invented. The corn cob is its own food piece.
