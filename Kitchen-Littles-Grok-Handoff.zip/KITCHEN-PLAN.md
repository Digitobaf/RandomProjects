# Kitchen Littles — how the kitchen works

This is the working design after the user finished supplying the initial sets. It includes storage, cooking/serving relationships, relative scale and a sound handoff. Artwork remains draft; the Casey’s Room app has not been changed.

## Arrangement

Keep the approved warm wood, cream tile, autumn window and original purple outer frame. The fridge sits at far left in a bay with space for both doors to open inside the window. Left counter: toaster in front and narrow yellow can opener at the back/side. Stove in the middle. Right counter: blender beside stove, popcorn machine at far right. Keep a small landing space between appliances. Both counter surfaces align with the stove cooking surface, not its rear control panel.

The overhead blue-and-white gingham table below is the main preparation and serving area. It starts mostly clear. Countertop appliances stay mounted and readable; food, dishes, pans and tools move. Do not expand the appliance list to fill space. A sink/washing system is not required for this toy-play design.

## Storage

| Unit | Position | Contents |
| --- | --- | --- |
| Fridge/freezer | Far left | Left freezer: frozen breakfast, desserts and dinner. Right chiller: drinks/condiments in door; cake on upper shelf; pasta/pizza/salad/picnic food on middle shelves; turkey/breakfast on lower shelf; apples, tomato, grapefruit and corn in produce bin. |
| Breakfast pantry | Upper left | Cereals, Wonder loaf and two toast pieces, Italian loaf/wrapper, and jam. Prepared pancakes / French toast live in the fridge breakfast section. |
| Dish cupboard | Upper right | Large/small plates, bowl, mug, ordinary tumbler, shake vessel, the two drinking vessels and bowls. Table cutlery lives in its own drawer. |
| Cooking cupboard | Lower left beside stove | Two frying pans, square griddle, two pink saucepans and lids, green pasta pot and lid. Long cooking tools live in the tools drawer. |
| Baking/serving cupboard | Lower middle under blender | The single oval turkey roaster, round pizza tray, cake stand. Cake server and pizza wheel live in the tools drawer. |
| Canned-food cupboard | Lower right under popcorn | Three closed food cans with matching lids, flat pizza box and potato-chip bag. |

| Cutlery drawer | Under left worktop, above cooking cupboard | Divided slots for pink knife, fork, spoon and turquoise breakfast knife. |
| Cooking / serving drawer | Under blender, above baking cupboard | Spatula, both cooking/serving spoons, cake server, pizza wheel and ice-cream scooper. |

Only one storage unit can be open globally, including both drawers. Both fridge doors count as one unit. Opening another closes the previous; clicking the current unit can close it. The oven, blender lid, pot lids, cake pieces and package lids are independent parts, so cooking can continue while a cupboard opens. Closing a cupboard never teleports removed objects back. Returning an object means placing it on its shelf or fitted tray; its stored home gives a reliable place to find it next time.

Show clear shelf groups and fitted trays instead of a wall of tiny icons. When a cupboard contains too much to pick comfortably, show one shelf/tray at a time inside that same open unit. Large roaster, tray and plates keep dedicated slots. A stored stack makes its front piece available, rather than obscuring every item behind it.

Every loose item may rest on the table or a clear counter landing spot. Stored positions remain consistent; placement in a bowl, pan, carton, tray or stand is a relationship to that container. Moving the container carries its contents. Taking the food out clears its old slot. At most one food insert occupies the floral bowl.

## Cooking and serving

### Eggs, bacon and toast

1. Take joined eggs and bacon from fridge; take pan and spatula from cooking cupboard.
2. Pan on burner; turn knob for gentle sizzling. Load two toast pieces into toaster and press lever.
3. Toast pops; move eggs, bacon and toast onto a large plate on the table.

One joined egg piece and one joined bacon piece stay intact.

### Waffles, pancakes or French toast

1. Waffles come from freezer; pancakes / French toast come from fridge breakfast section.
2. Waffles use toaster; pancakes / French toast use griddle on a burner.
3. Serve on side or dinner plate.

The syrup and butter are part of the molded pieces; nothing needs to be added.

### Pasta dinner

1. Take spaghetti disk from fridge; pot, matching lid and green spoon from cooking cupboard.
2. Spaghetti fits inside pot; put pot on burner and turn knob to simmer.
3. Lift cooked toy portion to Pasta plate; add Italian bread and bowl of salad.

Salad and vegetable use the single bowl one at a time.

### Turkey dinner

1. Turkey from lower fridge shelf; the one oval roaster from baking cupboard.
2. Fit turkey in roaster; move combined pan into oven, close door and set timer.
3. Amber glow while cooking; ding when done; move pan to table and lift turkey if wanted.

One turkey and one roaster; oven view never creates a second copy.

### Pizza Party

1. Assemble four chilled quarters on round metal tray.
2. Tray goes in oven; close door, set timer, wait for ding.
3. Move tray to table; roll green cutter along seams and lift quarters to plates.

Pizza box stores cooled pizza; the smaller Italian-pack pizza is a separate whole item.

### Ice-cream milkshake

1. Take Dreyer’s tub and milk from fridge; scooper and shake vessel from dish cupboard.
2. Open blender lid. Scoop up to three balls into jar; add milk and close lid.
3. Run blender, stop it, then pour one batch into the dedicated shake glass.

Three scoop balls become one batch; the filled shake is not a free extra copy.

### Crank popcorn machine

1. Turn the pink crank.
2. Enclosed white balls bounce under clear dome while turning.
3. Release crank; motion settles.

Popping audio follows cranking; the beads remain inside the toy.

### Open a food can

1. Take peach, SpaghettiOs or corn can, with its matched lid attached.
2. Fit can in opener recess and operate lever.
3. Lift detached lid and remove can; put matching lid back to close.

Lids fit their own cans. Cola can uses its tab; loose canned food is not in the current art set.

### Birthday cake

1. Cake from dessert shelf; stand and server from baking cupboard; dessert plate from dish cupboard.
2. Cake snaps onto stand on table.
3. Server lifts one segment to dessert plate; stand retains a visible gap until piece is returned.

Pieces can reassemble without creating a second whole cake.

### Frozen dinner and frozen treats

1. Frozen dinner comes out of Hungry-Man box; tray goes onto oven rack.
2. Close oven and set timer; serve meal in its divided tray.
3. Sandwiches and push-up pops go straight from freezer to table, served cold.

All boxes retain their fixed linked portions.

### Salad, vegetables and grapefruit

1. Choose salad, green vegetable or grapefruit from fridge.
2. Salad and grapefruit serve cold in bowl or on appropriate plate; vegetable may warm in saucepan.
3. One food insert fits the bowl at a time and lifts out again.

Whole tomato remains a loose whole toy; no slicing state is required.

### Milk, juice, cola and ice

1. Take the clear tumbler from dish cupboard and a carton / bottle / can from fridge.
2. Pour to change tumbler fill: white milk, orange juice or brown cola.
3. Glass under fridge dispenser plus lever gives ice; put drink on table.

One ordinary tumbler, separate shake vessel. No duplicate glass from each packaged set.

### Picnic lunch

1. Take sandwich, apples, hotdog / burger, franks packet, chicken, corn, condiments and soda from fridge as wanted; chips from canned-food/snack cupboard.
2. Sandwich / apples serve cold. Assembled hotdog / burger may warm on griddle; cooked drumsticks may warm in pan or existing oven roaster; corn fits large saucepan.
3. Set lunch on dinner or side plates on the gingham table; add ketchup, mustard, chips bag and lemon-lime soda.

Reuse Wonder loaf. No extra barbecue, picnic basket or raw burger/frank pieces are needed.

## Relative size

Full-size kitchen-equivalent cm, used as ratios only; counter and stove body height = 90. Not toy measurements or screen pixels.

Use one world scale for shelves, counters, table and object fit. The table camera is overhead and the kitchen camera is front-facing; projection and alternate views may change, but an item keeps its underlying dimensions. Measure the visible toy silhouette, excluding transparent canvas margins and halos. Handles, crank reach and opening doors belong in fit/clearance bounds.

Start with stove body height 90 and width 60. Counters share height 90; fridge height 175 is just under twice counter height. The countertop pieces remain prominent without enlarging them independently on every surface. Tiny parts get generous invisible pick areas rather than oversized artwork.

| Anchor / item | Width or diameter | Height | Relation |
| --- | ---: | ---: | --- |
| Counter / stove body | Stove width 60 | 90 | Shared worktop level; rear control panel sits above it |
| Fridge | 90 | 175 | Nearly twice counter height; reserve door swing inside scene |
| Toaster | 30 | 21 | Half stove width |
| Blender including handle | 23 | 42 | Tallest countertop appliance |
| Popcorn machine including side handles | 36 | 27 | Wider and lower than blender; crank clearance extra in front |
| Can opener | 12 | 22 | Smaller than toaster, taller than food cans |
| Dinner / Pasta / large serving plate | 26 | 2 | Basis for food portions |
| Side / dessert plate | 18 | 1.6 | About two-thirds dinner-plate diameter |
| Floral bowl | 16 outside / 14 opening | 7 | Inserts fit the opening |
| Ordinary tumbler | 7 | 11 | Short straight-sided thick-base glass from latest ice-dispenser reference |
| Milk / orange juice carton | 7 | 22 | Almost twice tumbler height |
| Cola bottle | 8 | 27 | Taller than cartons and cans |
| Food can | 7.5 | 12 | Fits opener recess |
| Shake vessel | 8 | 18 | Taller than ordinary tumbler |
| Party pizza / tray | 30 / 34 | 2 | Whole pizza larger than dinner plate; quarter fits plate |
| Small Italian pizza | 18 | 2 | Fits dinner plate whole |
| Spaghetti / pot opening | 19 / 22 | 3 food / 15 pot | Food stays visibly inside pot rim |
| Cake / stand top | 20 / 24 | 9 cake / 10 stand | Whole cake larger than dessert plate |
| Turkey / roaster | 36 / 42 | 24 turkey / 8 pan | Assembled turkey fits oven headroom |

Picnic proportions: hotdog 16 long, burger 10 diameter, sandwich 11 square, corn 13 long, each drumstick 12 long, apples 7 diameter. Ketchup bottle height 23, mustard bottle 13, lemon-lime soda bottle 27. A whole burger fits the 18 cm side plate; hotdog and corn fit a 26 cm dinner plate with room for a side. The assembled burger / hotdog and sandwich remain single toys, not stacks of invented new ingredients.

Usable oven plan: 46 wide, 43 deep and 29 high in the same units. Pizza tray diameter 34 and roaster footprint 42 x 30 fit with clearance. Eggs and bacon fit the large frying pan; pancakes and French toast fit the griddle. Toast and waffles are about 10 across; spoon/fork/knife handles are smaller than serving tools. No plate-sized tomatoes, carton-sized glasses or pan-sized single pancakes.

## Consistent toy behaviour

- One inventory identity per object. Alternate camera views, filled states and cooked states never create copies. The four party-pizza quarters remain four pieces even when assembled.
- Packages and prepared portions have fixed relationships. There are two waffles, two sandwiches, three push-up pops and three ice-cream balls. Returning pieces restores the package, not another copy. The Wonder toy loaf stays intact; its two toast pieces are its reusable breakfast pieces.
- Whole egg is a movable toy from the carton. The joined two-fried-egg piece is a separate already-molded breakfast portion, so one loose egg does not magically become two eggs.
- Cooking is gentle toy play: fit food to pan/tray, operate knob/lever, see warmth or motion, hear supplied sound, then serve. Molded food retains its recognisable shape. Eggs/bacon sizzle; pot contents simmer; oven glows; toaster pops. No failure/burning timers required.
- One ordinary tumbler has milk/orange/cola/ice states, and one dedicated shake vessel holds the shake. Filling replaces liquid state rather than stacking drinks. Milkshake ingredients transfer into one batch and then one filled vessel; a toy reset can restore ingredients without retaining a duplicate finished drink.
- A wrong container leaves the object where it was; a valid target gives a small visible fit cue and snaps it into the correct position. Pickup should be forgiving at the small window size.
- Save object locations, container contents, open storage unit and appliance/food state. Restore idle cooking states consistently. Sound loops stop when their action stops or the program closes. Use user-supplied audio; no substitute sounds have been invented.

## Sound handoff

ITEMS-AND-SOUNDS.md is the readable working inventory. ITEMS-AND-SOUNDS.csv has one row per item entry and a blank sound_file column. SOUND-CUES.csv groups action keys, with blank filenames, so one shared placement sound can cover several passive objects. Distinct appliance sounds are most useful first: toaster lever/pop, blender start/run/stop, popcorn crank/pop, can opener, fridge ice, stove sizzle/boil, oven timer/ding, and doors.

## Remaining preparation

The present art sheets need clean alpha and individual extraction. Scale ratios are specified, but actual sprite trimming/resizing and placement in the small approved window are still to be done. Open cupboard interiors, the empty kitchen background, several action/fill states and the exact original outer-frame source are still needed before integration. Sound cues are a handoff list, not a claim that audio files already exist.
