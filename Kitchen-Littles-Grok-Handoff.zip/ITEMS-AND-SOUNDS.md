# Kitchen Littles — working item and sound list

All entries below have visual draft art. They are not yet isolated finished sprites or implemented interactions. No sound files have been supplied or assigned.

98 item entries: 6 fixed appliances and 92 movable-item entries. Some entries contain two, three or four matching pieces. Open/closed views and filled/empty views are states, not extra inventory.

Use ITEMS-AND-SOUNDS.csv to assign a filename per item. SOUND-CUES.csv lists shared action cues once, so you can supply one clink for several dishes or separate variations. A quiet movable object only needs a placement sound if you want one.

The ordinary clear glass uses empty, milk, orange-juice, cola and ice states. Matching empty/ice glass drafts and loose clear cube views now exist. Orange-filled draft exists but needs matching to the newest glass silhouette; milk and cola fills still need artwork. The tall milkshake has its own vessel. This is the proposed reuse rule, rather than adding another tumbler for every set.

## Fixed appliance

Kitchen wall.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Side-by-side fridge with ice dispenser | 1 | Stores frozen and chilled items; dispenses ice into the tumbler | fridge.open, fridge.close, fridge.ice |
| Four-burner stove and oven | 1 | Burners accept pans/pots; oven accepts turkey roaster, pizza tray and frozen dinner | stove.on, stove.sizzle, stove.boil, oven.open, oven.close, oven.timer, oven.done |
| Metal floral toaster | 1 | Two toast pieces or two frozen waffles; lever down, heat, pop up | toaster.lever, toaster.pop |
| Metal floral blender | 1 | Accepts three ice-cream scoops and milk; lid closes before blending | blender.lid, blender.start, blender.run, blender.stop, drink.pour |
| Pink crank popcorn machine | 1 | Turning crank makes enclosed white balls bounce; they settle when released | popcorn.crank, popcorn.pop |
| Yellow can opener | 1 | Receives one of the three food cans; lever releases its matching removable lid | canopener.lever, canopener.open, can.lid |

## Fridge / freezer

Far left; both doors belong to one storage unit.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Syrup-and-butter pancakes | 2 | Warm on griddle, then serve; raised butter pat belongs on each | stove.sizzle, food.serve |
| Syrup-and-butter triangular French toast | 2 | Warm on griddle, then serve; distinct from plain toaster toast | stove.sizzle, food.serve |
| Red / white / blue MILK carton | 1 | Pour into tumbler or blender; shared carton across all sets | drink.pour, place.packet |
| Tropicana orange juice carton | 1 | Pour into tumbler to use orange-filled glass state | drink.pour, place.packet |
| Brown COLA bottle with red label and white cap | 1 | Serve beside pasta or pour into clear tumbler | soda.open, drink.pour, place.bottle |
| Red COLA can with repeated white lettering | 1 | Serve with pizza or pour into tumbler; opens by tab, not yellow can opener | soda.open, drink.pour, place.can |
| Round molded salad insert | 1 | Snaps into separate floral bowl; lifts out again; served cold | food.fit, place.food |
| Folded green vegetable insert | 1 | Fits bowl for serving or saucepan for warming; bowl holds one insert at a time | food.fit, stove.boil |
| Whole molded red tomato | 1 | Loose side / salad prop; remains whole | place.food |
| Pink grapefruit half with red centre nub | 1 | Fits bowl or side plate; no bowl baked into food art | food.fit, place.food |
| Spaghetti disk with red sauce and three meatballs | 1 | Cook / warm as one molded portion in Pasta Fun pot; serve on large plate | stove.boil, food.serve |
| Small whole Italian-pack pizza | 1 | Warm on pizza tray in oven; serves whole on plate; distinct from quartered party pizza | food.serve, place.food |
| Molded whole turkey | 1 | Put into oval roaster, bake, carry pan to table; turkey can lift out | food.serve, place.food |
| Pink / purple iced birthday cake and removable slice | 1 | Moves onto stand; server lifts segments along existing molded seams | cake.serve, place.food |
| One joined double-fried-egg piece | 1 | Existing two-egg toy portion: pan to breakfast plate; not two loose fried eggs | stove.sizzle, food.serve |
| One joined wavy bacon piece | 1 | Pan to breakfast plate; connected strips remain one toy piece | stove.sizzle, food.serve |
| Thin Sliced Bacon packet | 1 | Package paired with existing joined bacon portion | wrapper.bacon, place.packet |
| Yellow AAA LARGE EGGS carton | 1 | Opens to wells; pairs with loose egg and existing fried-egg toy portion | eggcarton.open, eggcarton.close, place.packet |
| Loose white toy egg | 1 | Lifts out and slots back into carton; fried double-egg piece remains a separate molded toy portion | egg.place |
| Open Dreyer’s Grand ice-cream tub | 1 | Holds exactly three separate scoop balls; empty tub art exists | place.packet, icecream.scoop |
| Striped Dreyer’s tub lid | 1 | Removable, matched to its tub | icecream.lid |
| White ice-cream scoop balls | 3 | Scooper to blender; exactly three available; all consumed portions belong to the one shake batch | icecream.scoop, food.fit |
| Three-colour ICE CREAM brick carton | 1 | Movable closed ice-cream package; distinct from Dreyer’s tub and ice-cream sandwiches | place.packet |
| Ice-cream sandwiches | 2 | Ready to serve cold | place.food |
| Blue Ice Cream Sandwiches box | 1 | Holds the two sandwich pieces; no endless duplicate portions | box.open, place.packet |
| Round frozen waffles | 2 | Toaster slots to plate | toaster.pop, place.food |
| Frozen Waffles box | 1 | Holds the two waffles | box.open, place.packet |
| Striped push-up ice pops | 3 | Ready to serve cold; pop/slider action can use existing molded shape | pushup.slide, place.food |
| Push-Up ice-pop box | 1 | Holds three pops | box.open, place.packet |
| Oval divided frozen-dinner tray | 1 | Removes from box, warms on oven rack, serves as one molded meal | place.metal, food.serve |
| Hungry-Man frozen-dinner box | 1 | Holds one divided dinner tray | box.open, place.packet |
| Pizza Party quarter slices | 4 | Fit together on 34 cm tray; oven, cutter along seams, lift one quarter to plate | pizza.cut, food.serve |
| Complete hot dog in bun with mustard stripe | 1 | Ready-made molded food; optional gentle griddle warming, then dinner plate | food.serve, place.food |
| Complete hamburger with tomato and lettuce | 1 | Ready-made molded burger; optional gentle griddle warming, then side or dinner plate | food.serve, place.food |
| David’s Franks packet | 1 | Chilled package paired with hotdog play; no additional loose frank pieces currently prepared | wrapper.franks, place.packet |
| Yellow corn on the cob | 1 | Fits large saucepan for simmering or griddle for warming; then dinner plate | stove.boil, food.serve |
| Red toy apple | 1 | Whole fruit beside picnic sandwich or on side plate | place.food |
| Green toy apple | 1 | Whole fruit beside picnic sandwich or on side plate | place.food |
| Hunt’s ketchup bottle | 1 | Table condiment beside hotdog / burger; cap action needs state preparation | condiment.cap, place.bottle |
| Yellow mustard bottle with red cap | 1 | Table condiment beside hotdog / burger; cap action needs state preparation | condiment.cap, place.bottle |
| Green Lemon Lime soda bottle | 1 | Picnic drink; can share tumbler with a clear soda fill state | soda.open, drink.pour, place.bottle |
| Complete white-bread picnic sandwich | 1 | Serves cold on side or dinner plate; remains one assembled toy | place.food, food.serve |
| Golden-brown chicken drumsticks | 2 | Already cooked toy portions; may warm in pan or oven in existing roaster, then plate with corn | stove.sizzle, food.serve |

## Breakfast pantry

Upper left, above toaster.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Partly wrapped Wonder toy loaf | 1 | Pairs with two reusable toast pieces; molded loaf remains intact | wrapper.bread, place.packet |
| Plain butter-coloured toaster toast pieces | 2 | Load toaster slots and pop; plate afterward; no raised butter cubes | toaster.pop, place.food |
| Molded Italian loaf | 1 | Pairs with separate Italian wrapper; serves beside pasta / salad | wrapper.bread, place.food |
| Printed ITALIAN bread wrapper | 1 | Separate package, preserves loaf relationship | wrapper.bread, place.packet |
| Kellogg’s Corn Flakes cereal box | 1 | Breakfast table / cereal source; cereal-in-bowl state not yet prepared | place.packet, cereal.pour |
| Fruity-O’s cereal box | 1 | Breakfast table / cereal source; cereal-in-bowl state not yet prepared | place.packet, cereal.pour |
| Purple grape jam jar with white lid | 1 | Breakfast table beside bread / toast; open-jar state not yet prepared | jar.lid, place.glass |

## Dish cupboard

Upper right, above blender / popcorn maker.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Large rose-and-heart dinner plate | 1 | Breakfast, spaghetti, small pizza, or turkey serving | place.dish |
| Small rose-and-heart side plate | 1 | Toast, waffles, grapefruit or a small portion | place.dish |
| Rose-patterned bowl | 1 | Salad OR green vegetable insert snaps inside; also holds grapefruit; about 14 cm clear opening | place.dish, food.fit |
| Coral / pink mug | 1 | Table setting; drink vessel | place.dish |
| Clear drinking tumbler | 1 | Milk, orange juice, cola, or clear chunky toy ice; one vessel changes filled state | place.glass, drink.pour, fridge.ice |
| Small green-ring floral birthday plate | 1 | Receives cake slice | place.dish |
| Large green-ring floral birthday serving plate | 1 | Cake or shared serving plate | place.dish |
| Red-and-green-ring Pasta plate | 1 | Spaghetti or pizza quarter | place.dish |
| Tall milkshake with foam and bent white straw | 1 | Dedicated shake vessel, separate from ordinary tumbler; filled after one blender batch | drink.pour, place.glass |
| Turquoise floral-rim popcorn bowl | 1 | Holds the separate molded popcorn insert | place.dish, food.fit |

## Cooking cupboard

Lower left, beside stove.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Small pink-handled round frying pan | 1 | Eggs or a smaller breakfast portion; 20 cm pan body | place.metal, stove.sizzle |
| Large pink-handled round frying pan | 1 | Eggs and bacon; 24 cm usable pan opening | place.metal, stove.sizzle |
| Pink-handled square griddle | 1 | Pancakes or French toast | place.metal, stove.sizzle |
| Small pink-handled saucepan | 1 | Vegetable portion or small warming task | place.metal, stove.boil |
| Small pink-knob saucepan lid | 1 | Fits small pink saucepan only | lid.metal |
| Large pink-handled saucepan | 1 | Vegetable portion or warming task | place.metal, stove.boil |
| Large pink-knob saucepan lid | 1 | Fits large pink saucepan only | lid.metal |
| Green-handled Pasta Fun pot | 1 | Existing 19 cm spaghetti disk fits 22 cm clear opening; cook on burner | place.metal, stove.boil |
| Red-knob silver Pasta Fun lid | 1 | Fits Pasta Fun pot only | lid.metal |

## Baking / serving cupboard

Lower middle, under blender.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Oval metal turkey roasting pan | 1 | Holds turkey; fits 46 x 43 cm oven footprint; this is the only turkey pan | place.metal |
| Round metal pizza tray | 1 | Holds assembled 30 cm Pizza Party pizza or smaller Italian pizza; oven safe in play | place.metal |
| White cake pedestal stand | 1 | Receives 20 cm cake; carries remaining cake pieces together | place.dish |

## Canned-food cupboard

Lower right, under popcorn maker.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Del Monte Peach Halves can | 1 | Matching lid off/on; fits yellow opener; no loose peach contents have been prepared | place.can, canopener.open |
| Peach can silver lid with white plug | 1 | Fits peach can only; opener releases it | can.lid |
| Franco-American SpaghettiOs can | 1 | Matching lid off/on; fits yellow opener; separate from Italian spaghetti disk | place.can, canopener.open |
| SpaghettiOs can silver lid with red-brown plug | 1 | Fits SpaghettiOs can only | can.lid |
| Del Monte Whole Kernel Corn can | 1 | Matching lid off/on; fits yellow opener; no loose corn contents have been prepared | place.can, canopener.open |
| Corn can silver lid with ochre plug | 1 | Fits corn can only | can.lid |
| White / red / green PIZZA box | 1 | Closed empty home; can hold cooled assembled party pizza in play | box.open, place.packet |
| Red / yellow Potato Chips bag | 1 | Picnic table snack package; chips shown at bag opening, no loose chip pieces yet | wrapper.chips, place.packet |
| Molded yellow-and-ivory serving popcorn insert | 1 | Slots into popcorn bowl or serving dish; separate from enclosed mechanism balls | food.fit, place.food |
| Flat POP CORN packet | 1 | Serving popcorn package from the machine reference set | place.packet, wrapper.chips |

## Cutlery drawer

Shallow drawer under left counter, above cooking cupboard.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Pink-handled table knife | 1 | Table setting | place.cutlery |
| Pink-handled table fork | 1 | Table setting | place.cutlery |
| Pink-handled table spoon | 1 | Table setting | place.cutlery |
| Turquoise-handled knife from Toaster Fun | 1 | Bread / breakfast table setting; existing colour variant | place.cutlery |

## Cooking / serving tools drawer

Shallow drawer under blender, above baking cupboard.

| Item | Count | Use / action | Sound cue keys |
| --- | ---: | --- | --- |
| Turquoise-handled ice-cream scooper | 1 | Lifts one scoop at a time from tub and releases it in blender | icecream.scoop, place.cutlery |
| Green-handled Pasta Fun serving spoon | 1 | Moves spaghetti portion from pot to plate | place.cutlery, food.serve |
| Pink-handled metal cooking spoon | 1 | Cooking / serving tool | place.cutlery, food.serve |
| Pink-handled slotted spatula | 1 | Moves eggs, bacon, pancakes or French toast from pan to plate | place.cutlery, food.serve |
| Pink-handled cake server with turquoise collar | 1 | Lifts one existing cake segment to dessert plate | cake.serve, place.cutlery |
| Green-handled silver pizza wheel | 1 | Rolls along existing quarter seams; then slices can lift individually | pizza.cut, place.cutlery |

## Parts and states already represented

- Fridge and oven: open and closed views. Blender: lid and jar states. Popcorn: mounted crank and internal beads; these do not add loose inventory.
- Egg carton: open/closed. Tub, pots and food cans: matching removable lids are listed separately because they can lift off.
- Turkey/pan front oven view refers to the same two objects as their overhead views. Whole cake and served wedge refer to one cake. Four pizza quarters form one party pizza.
- Repeat milk cartons, clear glasses, table cutlery, bread and the turkey roaster are reused across sets. The small Italian pizza and larger quartered Party pizza are distinct toys.

## Artwork still needed for planned actions

- Clean alpha, individual sprite extraction, open cupboard interiors, empty kitchen background, final can-opener placement and the original approved outer-frame source.
- Milk/cola tumbler fills and orange fill matched to newest dispenser glass; empty shake vessel and blender contents; toast/waffle load and pop states; cake remainder with a gap. Empty/ice tumbler and loose cube views are now drafted.
- Open packaging/interiors where portions are taken out. Cereal bowl contents and open jam state are optional extensions; current art is the closed boxes/jar.
- No loose canned peach, corn kernels or SpaghettiOs contents, turkey carving portions, loose frank sausages, loose potato chips, or edible served-popcorn pile are currently prepared. The new whole corn cob is a distinct food piece. Can opening and enclosed popcorn-ball motion can work with the present toy set.
