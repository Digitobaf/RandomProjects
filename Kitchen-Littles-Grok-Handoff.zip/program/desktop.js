(() => {
  'use strict';
  const K=window.CaseyKitchen;
  if(!K)return;
  function attach(frame){
    if(!frame?.url||!frame?.content||!frame?.minimize||!frame?.close)throw new Error('Kitchen Littles needs the original approved frame and its measured controls.');
    const screen=document.getElementById('screen'),icons=document.getElementById('icons'),taskbar=document.getElementById('taskbar'),tray=document.getElementById('tray');
    if(!screen||!icons||!taskbar||!tray)throw new Error('Casey’s Room desktop was not found.');
    if(document.getElementById('caseyKitchenIcon'))return K;
    const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
    const button=(label,cls,fn)=>{const b=el('button',cls);b.type='button';b.title=label;b.setAttribute('aria-label',label);if(fn)b.addEventListener('click',fn);return b;};
    const root=K.mount(screen,{frame:frame.url,geometry:frame.content});
    const data=K.getData(),sprite=data.assets.sprites.popcorn,atlas=data.assets.atlas[sprite.source],cell=sprite.cells[0];
    const iconSvg='<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="'+cell.join(' ')+'"><image href="'+atlas.url+'" width="'+atlas.width+'" height="'+atlas.height+'"/></svg>';
    const iconUrl='data:image/svg+xml;base64,'+btoa(unescape(encodeURIComponent(iconSvg)));
    const icon=button('Kitchen Littles','icon');icon.id='caseyKitchenIcon';const ii=el('img');ii.src=iconUrl;ii.alt='';icon.append(ii,el('span','','Kitchen Littles'));icon.title='Kitchen Littles — double-click to open';icons.append(icon);
    const task=button('Kitchen Littles','tb',()=>root.hidden||!frontmost?show():minimize());task.id='caseyKitchenTask';task.hidden=true;const ti=el('img');ti.src=iconUrl;ti.alt='';task.append(ti,document.createTextNode('Kitchen Littles'));taskbar.insertBefore(task,tray);
    const coreShow=K.show,coreHide=K.hide,coreClose=K.close,coreLayout=K.layout;
    let opened=false,frontmost=false,drag=null,tabbing=false;
    function front(){frontmost=true;root.style.zIndex='14700';task.classList.add('dn');}
    function layout(){if(!opened)return;const sw=screen.clientWidth,sh=Math.max(1,screen.clientHeight-32),aspect=frame.width/frame.height,w=Math.max(1,Math.min(frame.preferredWidth||Math.min(640,frame.width),sw-12,(sh-10)*aspect)),h=w/aspect;
      const pos=K.getState().window;root.style.width=w+'px';root.style.height=h+'px';root.style.left=Math.round(Math.max(0,sw-w)*pos.x)+'px';root.style.top=Math.round(Math.max(0,sh-h)*pos.y)+'px';coreLayout();}
    function show(){opened=true;root.hidden=false;task.hidden=false;document.querySelectorAll('#icons .icon').forEach(n=>n.classList.remove('sel'));layout();front();coreShow();root.querySelector('[data-storage]')?.focus({preventScroll:true});}
    function minimize(){coreHide();frontmost=false;task.classList.remove('dn');task.focus({preventScroll:true});}
    function close(){coreClose();opened=false;frontmost=false;task.hidden=true;task.classList.remove('dn');}
    function control(label,geometry,fn){const b=button(label,'kl-window-control',fn);b.style.left=geometry.left+'%';b.style.top=geometry.top+'%';b.style.width=geometry.width+'%';b.style.height=geometry.height+'%';root.append(b);return b;}
    control('Minimize Kitchen Littles',frame.minimize,minimize);control('Close Kitchen Littles',frame.close,close);
    const dragArea=el('div','kl-window-drag');dragArea.setAttribute('aria-label','Move Kitchen Littles window');
    if(frame.drag){for(const key of ['left','top','width','height'])if(Number.isFinite(frame.drag[key]))dragArea.style[key]=frame.drag[key]+'%';dragArea.style.right='auto';}
    root.append(dragArea);
    dragArea.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();front();const sr=screen.getBoundingClientRect();drag={id:e.pointerId,x:e.clientX,y:e.clientY,left:root.offsetLeft,top:root.offsetTop,scale:sr.width/screen.clientWidth||1};dragArea.setPointerCapture(e.pointerId);});
    dragArea.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;const mx=Math.max(0,screen.clientWidth-root.offsetWidth),my=Math.max(0,screen.clientHeight-32-root.offsetHeight),x=Math.max(0,Math.min(mx,drag.left+(e.clientX-drag.x)/drag.scale)),y=Math.max(0,Math.min(my,drag.top+(e.clientY-drag.y)/drag.scale));K.setWindowPosition(mx?x/mx:0,my?y/my:0);layout();});
    for(const event of ['pointerup','pointercancel','lostpointercapture'])dragArea.addEventListener(event,()=>{if(drag){drag=null;K.actions.save();}});
    icon.addEventListener('mousedown',e=>{e.stopPropagation();document.querySelectorAll('#icons .icon').forEach(n=>n.classList.toggle('sel',n===icon));});icon.addEventListener('dblclick',show);icon.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'||e.key===' '){e.preventDefault();show();}});task.addEventListener('keydown',e=>e.stopPropagation());
    document.getElementById('startB')?.addEventListener('click',()=>{const menu=document.getElementById('drop');if(!menu||menu.style.display==='none'||menu.querySelector('[data-kitchen-menu]'))return;const row=el('div','it');row.dataset.kitchenMenu='true';row.append(el('span','','Kitchen Littles'),el('span',''));row.addEventListener('mouseup',e=>{e.preventDefault();e.stopPropagation();document.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));show();});const after=menu.querySelector('[data-crystal-menu]')||menu.querySelector('[data-gba-menu]');menu.insertBefore(row,after?.nextSibling||menu.children[1]||null);const sr=screen.getBoundingClientRect(),br=document.getElementById('startB').getBoundingClientRect(),scale=sr.width/screen.clientWidth||1;menu.style.top=((br.top-sr.top)/scale-menu.offsetHeight)+'px';});
    root.addEventListener('pointerdown',front);
    screen.addEventListener('pointerdown',e=>{if(opened&&!root.hidden&&!root.contains(e.target)&&!icon.contains(e.target)&&!task.contains(e.target)){frontmost=false;root.style.zIndex='4';task.classList.remove('dn');}},true);
    document.addEventListener('keydown',e=>{if(e.key==='Tab'){tabbing=true;setTimeout(()=>{tabbing=false;},0);}},true);
    document.addEventListener('focusin',e=>{const modal=document.getElementById('modal');if(frontmost&&!root.hidden&&!tabbing&&root.contains(e.relatedTarget)&&e.target.closest?.('#caseyAIM')&&(!modal||getComputedStyle(modal).display==='none'))e.relatedTarget.focus({preventScroll:true});});
    window.addEventListener('resize',layout);if(window.ResizeObserver)new ResizeObserver(layout).observe(screen);
    Object.assign(K,{show,hide:minimize,close,layout});return K;
  }
  K.attachDesktop=attach;
  const frame=K.getData().frame;
  if(frame?.url&&document.getElementById('screen'))attach(frame);
})();
