from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).parent
REPORT={'checks':[],'errors':[]}

def record(name,details=True):
    REPORT['checks'].append({'name':name,'details':details})

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':1000,'height':700})
    page=context.new_page()
    errors=[];requests=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:requests.append(r.url) if not r.url.startswith(('data:','http://127.0.0.1:8899/')) else None)
    page.goto('http://127.0.0.1:8899/harness.html')
    page.wait_for_function('window.CaseyKitchen && document.querySelector("#caseyKitchen .kl-background")')
    def js(code,arg=None):return page.evaluate('(arg)=>{const K=CaseyKitchen,A=K.actions;'+code+'}',arg)
    def state():return js('return K.getState();')
    def reset():js('K.reset();');page.wait_for_timeout(30)
    def drop(uid,target):return js('return A.drop(arg.uid,arg.target);',{'uid':uid,'target':target})
    reset()
    audit=js('return K.verify();')
    assert audit['ok'] and audit['inventoryEntries']==98 and audit['movableInstances']==105
    expected_foods={'toast','wonder-loaf','italian-loaf','milk-carton','orange-juice-carton','cola-bottle','cola-can','lemon-lime-soda','salad-insert','vegetable-insert','tomato','grapefruit','spaghetti','italian-pizza','turkey','birthday-cake','fried-eggs','bacon-piece','bacon-packet','egg-carton','loose-egg','pancakes','french-toast','corn-flakes','fruity-os','grape-jam','icecream-tub','icecream-scoops','milkshake','icecream-brick-carton','icecream-sandwiches','sandwich-box','frozen-waffles','waffle-box','push-up-pops','push-up-box','frozen-dinner','frozen-dinner-box','peach-can','spaghettios-can','corn-can','pizza-quarters','pizza-box','hotdog','burger','franks-packet','corn-cob','red-apple','green-apple','ketchup','mustard','picnic-sandwich','chicken-drumsticks','potato-chips-bag','popcorn-insert','popcorn-packet'}
    catalog=js('return K.getCatalog();')
    assert expected_foods<={x['id'] for x in catalog}
    assert js('return K.getCatalog().every(x=>K.getData().assets.sprites[x.id]);')
    record('All reference-set food/package types accounted for, every catalogue entry has art and a home',{'catalogue':98,'food_package_types':len(expected_foods),'loose_instances':105})

    # Open each actual storage button, including drawers, and verify exclusive state.
    for unit in ['fridge','cutlery','tools','pantry','dishes','cookware','baking','cans']:
        page.locator('[data-storage="'+unit+'"]').click()
        page.wait_for_timeout(30)
        assert state()['open']==unit
        assert page.locator('[data-storage][aria-expanded=true]').count()==1
    record('Fridge, cupboards and both drawers share one-open-storage rule')

    # A real pointer click retains selection; a real drag takes a utensil from drawer to table.
    reset();js('A.open("cutlery");A.render();')
    fork=page.locator('[data-uid="table-fork"]');fork.click()
    assert state()['selection']=='table-fork'
    box=fork.bounding_box();world=page.locator('.kl-world').bounding_box();scale=world['width']/1584
    page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);page.mouse.down();page.mouse.move(world['x']+600*scale,world['y']+800*scale,steps=8);page.mouse.up()
    assert state()['items']['table-fork']['loc']['kind']=='table'
    before=state()['items']['table-fork']['loc']
    page.locator('[data-storage="fridge"]').click();page.wait_for_timeout(30)
    assert state()['items']['table-fork']['loc']==before
    record('Pointer selection / drag works, and changing storage leaves removed pieces in place')

    reset()
    assert drop('salad-insert',{'kind':'item','uid':'floral-bowl'})
    assert not drop('vegetable-insert',{'kind':'item','uid':'floral-bowl'})
    assert drop('floral-bowl',{'kind':'table','x':700,'y':770})
    assert state()['items']['salad-insert']['loc']['parent']=='floral-bowl'
    assert drop('salad-insert',{'kind':'table','x':820,'y':770})
    assert drop('vegetable-insert',{'kind':'item','uid':'floral-bowl'})
    assert not drop('floral-bowl',{'kind':'item','uid':'vegetable-insert'})
    record('One bowl insert at a time; dishes carry food; removing an insert frees its slot; cycles rejected')

    reset();assert drop('pasta-lid',{'kind':'table','x':900,'y':800})
    assert drop('spaghetti',{'kind':'item','uid':'pasta-pot'})
    assert drop('pasta-pot',{'kind':'station','station':'burner0'})
    js('A.burner(0);');page.wait_for_timeout(4100)
    assert state()['items']['spaghetti']['warm']
    assert drop('green-serving-spoon',{'kind':'item','uid':'pasta-pot'})
    assert drop('green-serving-spoon',{'kind':'item','uid':'pasta-plate'})
    assert state()['items']['spaghetti']['loc']['parent']=='pasta-plate'
    record('Spaghetti cooks in pot and transfers with serving spoon to Pasta plate')

    reset()
    assert not drop('table-fork',{'kind':'station','station':'toaster'})
    assert drop('toast:0',{'kind':'station','station':'toaster'})
    assert drop('toast:1',{'kind':'station','station':'toaster'})
    assert not drop('frozen-waffles:0',{'kind':'station','station':'toaster'})
    js('A.toaster();K.setTestClock(80);');page.wait_for_timeout(160)
    assert not state()['machines']['toaster']['running'] and state()['items']['toast:0']['warm']
    assert len([x for x in state()['items'].values() if x['type']=='toast'])==2
    record('Toaster accepts only bread/waffles, has two slots, pops without duplicating pieces')

    reset();assert drop('turkey',{'kind':'item','uid':'turkey-roaster'})
    assert not drop('turkey-roaster',{'kind':'station','station':'oven'})
    js('A.ovenDoor();');assert drop('turkey-roaster',{'kind':'station','station':'oven'})
    js('A.ovenDoor();A.oven();K.setTestClock(80);');page.wait_for_timeout(160)
    assert state()['items']['turkey']['warm'] and not state()['machines']['oven']['running']
    js('A.ovenDoor();');assert drop('turkey-roaster',{'kind':'table','x':650,'y':750})
    assert state()['items']['turkey']['loc']['parent']=='turkey-roaster'
    record('Single turkey / roaster fits oven, timer finishes, and pan carries turkey to table')

    reset()
    for i in range(4):assert drop('pizza-quarters:'+str(i),{'kind':'item','uid':'pizza-tray'})
    assert drop('pizza-cutter',{'kind':'item','uid':'pizza-tray'})
    assert state()['items']['pizza-tray']['cut']
    assert drop('pizza-quarters:0',{'kind':'item','uid':'pasta-plate'})
    assert len([x for x in state()['items'].values() if x['loc'].get('parent')=='pizza-tray'])==3
    assert len([x for x in state()['items'].values() if x['type']=='pizza-quarters'])==4
    record('Four pizza quarters assemble / separate on tray with no fifth whole pizza')

    reset();assert drop('cake-server',{'kind':'item','uid':'birthday-cake'})
    assert drop('cake-server',{'kind':'item','uid':'birthday-small-plate'})
    portions=[x for x in state()['items'].values() if x['type']=='cake_slice']
    served=[x for x in portions if x['loc'].get('parent')=='birthday-small-plate'];assert len(served)==1
    assert drop(served[0]['uid'],{'kind':'item','uid':'birthday-cake'})
    assert all(x['loc']['kind']=='cake' for x in state()['items'].values() if x['type']=='cake_slice')
    record('Cake server lifts one of four conserved segments; returning it reassembles cake')

    reset();assert drop('icecream-tub-lid',{'kind':'table','x':500,'y':800})
    assert state()['items']['icecream-tub']['open']
    js('A.blenderLid();')
    for i in range(3):
        assert drop('ice-cream-scoop-tool',{'kind':'item','uid':'icecream-tub'})
        assert drop('ice-cream-scoop-tool',{'kind':'station','station':'blender'})
    assert not drop('ice-cream-scoop-tool',{'kind':'item','uid':'icecream-tub'})
    assert drop('milk-carton',{'kind':'station','station':'blender'})
    js('A.blenderLid();A.blend();K.setTestClock(80);');page.wait_for_timeout(160)
    assert state()['machines']['blender']['blended']
    assert drop('milkshake',{'kind':'table','x':820,'y':750})
    js('A.select("milkshake");A.pourShake();')
    assert state()['items']['milkshake']['fill']=='shake'
    assert len([x for x in state()['items'].values() if x['type']=='icecream-scoops' and x['loc']['kind']=='batch'])==3
    record('Three scoops transfer via tool, blend with milk, then become one shake batch')

    reset();assert drop('corn-can',{'kind':'station','station':'opener'})
    js('A.can();')
    assert state()['items']['corn-lid']['loc']['kind']=='table'
    assert not drop('peach-lid',{'kind':'item','uid':'corn-can'})
    assert drop('corn-lid',{'kind':'item','uid':'corn-can'})
    assert state()['items']['corn-lid']['loc']['kind']=='lid'
    record('Can opener releases matching lid; wrong lid rejected; correct lid refits')

    reset();assert drop('tumbler',{'kind':'station','station':'dispenser'})
    js('A.ice();A.ice();A.ice();')
    assert state()['items']['tumbler']['ice']==3
    assert drop('orange-juice-carton',{'kind':'item','uid':'tumbler'})
    assert state()['items']['tumbler']['fill']=='orange'
    assert len([x for x in state()['items'].values() if x['type']=='tumbler'])==1
    js('A.crank(4);');page.wait_for_timeout(100)
    assert state()['machines']['popcorn']['turns']==4
    record('Dispenser adds clear-ice state to the one tumbler; drink fills reuse it; crank drives toy')

    # Actual save/reload and hidden-window timing behavior.
    assert drop('hotdog',{'kind':'table','x':620,'y':780})
    js('A.open("tools");A.save();');expected=state()
    page.reload();page.wait_for_function('window.CaseyKitchen && document.querySelector("#caseyKitchen .kl-background")')
    assert state()['items']['hotdog']['loc']==expected['items']['hotdog']['loc']
    assert state()['items']['tumbler']['ice']==3 and state()['open']=='tools'
    reset();drop('toast:0',{'kind':'station','station':'toaster'});js('A.toaster();K.hide();');remaining=state()['machines']['toaster']['remaining']
    page.wait_for_timeout(250);assert state()['machines']['toaster']['remaining']==remaining
    js('K.show();K.setTestClock(50);');page.wait_for_timeout(130);assert not state()['machines']['toaster']['running']
    record('Arrangement, contents and open drawer survive reload; hidden window pauses cooking / animation')

    context.set_offline(True)
    js('A.open("fridge");A.render();');page.wait_for_timeout(100)
    assert js('return K.verify().ok;')
    for width in [500,640,1000]:
        page.set_viewport_size({'width':width,'height':720});page.wait_for_timeout(60)
        bounds=page.locator('#caseyKitchen').bounding_box();assert bounds['x']>=0 and bounds['width']<=width+1
        assert not page.evaluate('document.documentElement.scrollWidth>innerWidth')
    page.set_viewport_size({'width':800,'height':650});js('K.reset();A.open("tools");A.render();')
    page.screenshot(path=str(ROOT/'qa-tools.png'),full_page=True)
    record('All artwork works offline; game stays within 500, 640 and 1000 pixel preview widths')
    assert not errors,errors
    assert not requests,requests
    REPORT['browser_errors']=errors;REPORT['external_requests']=requests;REPORT['inventory']=js('return K.verify();')
    REPORT['scope']='Internal gameplay preview; exact approved window artwork still required for integration.'
    (ROOT/'qa-results.json').write_text(json.dumps(REPORT,indent=2)+'\n')
    print(json.dumps({'passed':len(REPORT['checks']),'inventory':REPORT['inventory'],'errors':errors}))
    browser.close()
