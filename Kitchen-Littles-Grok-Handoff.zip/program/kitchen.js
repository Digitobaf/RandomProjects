/* Kitchen Littles owns its elements, timers, media and storage. */
(() => {
  'use strict';
  const DATA=__KITCHEN_DATA__;
  const NS='http://www.w3.org/2000/svg', KEY='caseysRoomKitchen:v1';
  const W=1584,H=993, defs=Object.fromEntries(DATA.plan.items.map(x=>[x.id,x]));
  const $=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
  const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
  const copy=x=>JSON.parse(JSON.stringify(x));
  const rect=(x,y,w,h)=>({x,y,w,h});
  const fixed={fridge:rect(130,48,300,610),fridgeOpen:rect(8,33,540,625),stove:rect(843,232,285,425),toaster:rect(665,231,173,111),blender:rect(1150,127,147,218),popcorn:rect(1325,194,205,151),opener:rect(580,226,77,118)};
  const units={
    fridge:{name:'Fridge / freezer',r:rect(10,35,535,625),hit:rect(125,48,310,610),pageSize:6},
    pantry:{name:'Breakfast pantry',r:rect(573,45,227,109),hit:rect(560,32,250,133),pageSize:4},
    dishes:{name:'Dishes',r:rect(1252,47,298,104),hit:rect(1240,32,329,133),pageSize:4},
    cookware:{name:'Pots & pans',r:rect(566,421,255,218),hit:rect(555,414,282,242),pageSize:4},
    baking:{name:'Baking & serving',r:rect(1135,424,210,215),hit:rect(1120,414,235,242),pageSize:2},
    cans:{name:'Cans & snacks',r:rect(1370,376,192,265),hit:rect(1358,367,214,289),pageSize:4},
    cutlery:{name:'Cutlery',r:rect(562,372,266,170),hit:rect(556,365,279,50),pageSize:4,drawer:true},
    tools:{name:'Cooking tools',r:rect(1128,372,220,181),hit:rect(1120,365,237,50),pageSize:3,drawer:true}
  };
  const stations={
    burner0:rect(859,276,108,61),burner1:rect(979,276,108,61),burner2:rect(870,304,108,51),burner3:rect(991,304,108,51),
    oven:rect(879,450,211,107),toaster:rect(693,230,115,47),blender:rect(1169,175,87,131),
    opener:rect(582,259,76,78),dispenser:rect(151,234,122,182)
  };
  const plateTypes=new Set(['dinner-plate','side-plate','birthday-small-plate','birthday-large-plate','pasta-plate']);
  const bowlTypes=new Set(['floral-bowl','popcorn-bowl']);
  const panTypes=new Set(['pink-frying-pan-small','pink-frying-pan-large','pink-griddle','pink-saucepan-small','pink-saucepan-large','pasta-pot','turkey-roaster','pizza-tray']);
  const toolTypes=new Set(['pink-spatula','pink-cooking-spoon','green-serving-spoon','cake-server','pizza-cutter','ice-cream-scoop-tool']);
  const foodTypes=new Set(['toast','pancakes','french-toast','fried-eggs','bacon-piece','salad-insert','vegetable-insert','tomato','grapefruit','spaghetti','italian-pizza','turkey','birthday-cake','icecream-scoops','icecream-sandwiches','frozen-waffles','push-up-pops','frozen-dinner','pizza-quarters','hotdog','burger','corn-cob','red-apple','green-apple','picnic-sandwich','chicken-drumsticks','popcorn-insert','italian-loaf']);
  const frozenTypes=new Set(['icecream-tub','icecream-tub-lid','icecream-scoops','icecream-brick-carton','icecream-sandwiches','sandwich-box','frozen-waffles','waffle-box','push-up-pops','push-up-box','frozen-dinner','frozen-dinner-box']);
  const packageChildren={toast:'wonder-loaf','italian-loaf':'italian-wrapper','icecream-scoops':'icecream-tub','icecream-sandwiches':'sandwich-box','frozen-waffles':'waffle-box','push-up-pops':'push-up-box','frozen-dinner':'frozen-dinner-box','loose-egg':'egg-carton','popcorn-insert':'popcorn-packet'};
  const lids={'pink-lid-small':'pink-saucepan-small','pink-lid-large':'pink-saucepan-large','pasta-lid':'pasta-pot','icecream-tub-lid':'icecream-tub','peach-lid':'peach-can','spaghettios-lid':'spaghettios-can','corn-lid':'corn-can'};
  const canLids={'peach-can':'peach-lid','spaghettios-can':'spaghettios-lid','corn-can':'corn-lid'};
  const liquids={'milk-carton':'milk','orange-juice-carton':'orange','cola-bottle':'cola','cola-can':'cola','lemon-lime-soda':'soda'};
  const containerTypes=new Set([...plateTypes,...bowlTypes,...panTypes,...Object.values(packageChildren),...Object.values(lids),'cake-stand',...toolTypes]);
  const EMPTY_SHAKE='milkshake';
  function initial(){
    const items={};let order=0;
    for(const d of DATA.plan.items){if(d.kind!=='movable')continue;for(let i=0;i<d.quantity;i++){
      const uid=d.quantity===1?d.id:d.id+':'+i;
      items[uid]={uid,type:d.id,index:i,home:d.home,loc:{kind:'home',unit:d.home},order:++order,open:false,fill:'',ice:0,warm:false};
    }}
    for(const p of Object.values(items)){
      const parent=packageChildren[p.type];if(parent)p.loc={kind:'inside',parent};
      if(lids[p.type])p.loc={kind:'lid',parent:lids[p.type]};
    }
    for(let i=0;i<4;i++)items['cake-slice:'+i]={uid:'cake-slice:'+i,type:'cake_slice',index:i,home:'fridge',loc:{kind:'cake',parent:'birthday-cake'},order:++order,open:false,warm:false};
    return {version:1,items,open:null,pages:{},selection:null,order,machines:{oven:{open:false,running:false,remaining:0},burners:[false,false,false,false],toaster:{running:false,remaining:0},blender:{lid:true,milk:false,blended:false,running:false,remaining:0},popcorn:{turns:0},opener:{open:false}},window:{x:.47,y:.12}};
  }
  let state=initial();
  try{const s=JSON.parse(localStorage.getItem(KEY)||'null');if(s&&s.version===1&&s.items){const fresh=initial();for(const id in fresh.items){if(s.items[id]&&s.items[id].type===fresh.items[id].type)Object.assign(fresh.items[id],s.items[id]);}fresh.open=units[s.open]?s.open:null;fresh.pages=s.pages||{};fresh.machines=Object.assign(fresh.machines,s.machines||{});fresh.window=Object.assign(fresh.window,s.window||{});fresh.order=Math.max(...Object.values(fresh.items).map(x=>x.order||0));state=fresh;}}catch(_){}
  let root,world,surface,opened=false,active=false,lastTime=0,raf=0,dirty=true,selectedBeforeDrag=null,drag=null,saveTimer=0,toastTimer=0;
  let frameArt=null,frameGeometry=null,backgroundUrl='',harness=false,positionDrag=null,sounds={},audioNodes=new Map(),hover=null,suppressWorldClickUntil=0;
  const nodeMap=new Map(),boxes=new Map(),tip=$('div','kl-tooltip'),message=$('span','kl-status-message');
  let lastMessage='Open a cupboard, fridge or drawer to choose something.';
  function persist(){clearTimeout(saveTimer);try{localStorage.setItem(KEY,JSON.stringify({...state,selection:null}));}catch(_){}}
  function save(){clearTimeout(saveTimer);saveTimer=setTimeout(persist,120);}
  function say(text){lastMessage=text;message.textContent=text;const sr=root?.querySelector('.kl-sr');if(sr)sr.textContent=text;}
  function sound(key,loop=false){
    root?.dispatchEvent(new CustomEvent('kitchen:sound',{detail:{key,loop},bubbles:true}));
    const url=sounds[key];if(!url||!active)return;
    let a=audioNodes.get(key);if(!a){a=new Audio(url);a.volume=.55;audioNodes.set(key,a);}a.loop=loop;
    if(!loop||a.paused){if(!loop)try{a.currentTime=0;}catch(_){}a.play().catch(()=>{});}
  }
  function stopSound(key){const a=audioNodes.get(key);if(a){a.pause();try{a.currentTime=0;}catch(_){}}}
  function stopAllSounds(){audioNodes.forEach(a=>a.pause());}
  function asset(name,index=0){const s=DATA.assets.sprites[name];if(!s)return null;const a=DATA.assets.atlas[s.source];return {url:a.url,w:a.width,h:a.height,cell:s.cells[index%s.cells.length]};}
  function svgSprite(name,index=0,glass=false){
    const a=asset(name,index);if(!a)return $('span');
    const s=document.createElementNS(NS,'svg');s.classList.add('kl-sprite');s.setAttribute('viewBox',a.cell.join(' '));s.setAttribute('preserveAspectRatio','none');
    const im=document.createElementNS(NS,'image');im.setAttribute('href',a.url);im.setAttribute('width',a.w);im.setAttribute('height',a.h);im.setAttribute('filter','url(#'+(glass?'kl-glass-alpha':'kl-solid-alpha')+')');s.append(im);return s;
  }
  function at(n,r){n.style.left=r.x+'px';n.style.top=r.y+'px';n.style.width=r.w+'px';n.style.height=r.h+'px';return n;}
  function makeButton(label,r,fn,cls='kl-hotspot'){const b=$('button',cls);b.type='button';b.title=label;b.setAttribute('aria-label',label);at(b,r);b.addEventListener('click',e=>{e.stopPropagation();fn(e);});return b;}
  function children(uid){return Object.values(state.items).filter(p=>p.loc.parent===uid);}
  function descendants(uid){const out=[];for(const c of children(uid)){out.push(c.uid,...descendants(c.uid));}return out;}
  function definition(p){return defs[p.type]||{id:'cake_slice',item:'Birthday cake slice',width:10,depth:10,height:6,quantity:4,home:'fridge',sound_keys:['cake.serve']};}
  function getRoot(p){const seen=new Set();while(p?.loc.parent&&!seen.has(p.uid)){seen.add(p.uid);p=state.items[p.loc.parent];}return p;}
  function stationContents(name){return Object.values(state.items).filter(x=>x.loc.kind==='station'&&x.loc.station===name);}
  function itemSize(p,capW=1000,capH=1000){
    const d=definition(p),a=asset(p.type==='cake_slice'?'cake_slice':p.type,p.index)||asset('tumbler');
    const ratio=a?a.cell[2]/a.cell[3]:1;
    let w=d.width*4.8,h=w/ratio;
    if(['table-knife','table-fork','table-spoon'].includes(p.type)){h=d.height*4.8;w=h*ratio;}
    if(p.type==='turquoise-knife'||toolTypes.has(p.type)){w=d.height*4.8;h=w/ratio;}
    if(['frozen-waffles','toast'].includes(p.type)){w=48;h=w/ratio;}
    if(p.type==='milkshake'){h=86;w=h*ratio;}
    if(p.type==='tumbler'){h=55;w=h*ratio;}
    if((unitRoot(p)==='tools'||p.type==='turquoise-knife'&&unitRoot(p)==='cutlery')&&ratio>1.8){const old=w;w=h;h=old;}
    const k=Math.min(1,capW/w,capH/h);return {w:w*k,h:h*k};
  }
  function applyMove(uid,loc){const p=state.items[uid];if(!p)return false;if(p.loc.kind==='lid'&&state.items[p.loc.parent])state.items[p.loc.parent].open=true;p.loc=copy(loc);p.order=++state.order;state.selection=uid;save();dirty=true;return true;}
  function rootsIn(unit){return Object.values(state.items).filter(p=>p.loc.kind==='home'&&p.loc.unit===unit).sort((a,b)=>a.order-b.order);}
  function unitRoot(p){const r=getRoot(p);return r?.loc.kind==='home'?r.loc.unit:null;}
  function pageFor(list,key,size){const count=Math.max(1,Math.ceil(list.length/size));state.pages[key]=clamp(state.pages[key]||0,0,count-1);return {items:list.slice(state.pages[key]*size,(state.pages[key]+1)*size),count,page:state.pages[key]};}
  function homePlacements(){
    const out=[];if(!state.open)return out;
    const u=units[state.open];
    if(state.open==='fridge'){
      const all=rootsIn('fridge'),frozen=all.filter(p=>frozenTypes.has(p.type)),cold=all.filter(p=>!frozenTypes.has(p.type));
      const fp=pageFor(frozen,'fridge-frozen',3),cp=pageFor(cold,'fridge-cold',6);
      fp.items.forEach((p,i)=>{const s=itemSize(p,83,105);out.push([p,rect(142+(86-s.w)/2,145+i*149+100-s.h,s.w,s.h)]);});
      cp.items.forEach((p,i)=>{const col=i%2,row=Math.floor(i/2),s=itemSize(p,80,108);out.push([p,rect(257+col*86+(80-s.w)/2,140+row*150+109-s.h,s.w,s.h)]);});
      return out;
    }
    const list=rootsIn(state.open),pg=pageFor(list,state.open,u.pageSize),cols=u.drawer?u.pageSize:Math.min(2,u.pageSize),rows=u.drawer?1:Math.ceil(u.pageSize/cols);
    const cw=(u.r.w-20)/cols,ch=(u.r.h-30)/rows;
    pg.items.forEach((p,i)=>{const s=itemSize(p,cw-12,ch-12);out.push([p,rect(u.r.x+10+(i%cols)*cw+(cw-s.w)/2,u.r.y+5+Math.floor(i/cols)*ch+ch-s.h,s.w,s.h)]);});return out;
  }
  function childBox(p,pr,index,count){
    const parent=state.items[p.loc.parent];if(!parent)return null;const t=parent.type;
    if(p.loc.kind==='cake'||p.loc.kind==='batch')return null;
    if(p.type==='turkey'&&parent.type==='turkey-roaster'&&parent.loc.kind==='station'&&parent.loc.station==='oven')return null;
    if(p.loc.kind==='lid'){
      const removed=parent.open;if(removed)return null;
      if(canLids[t])return rect(pr.x+pr.w*.06,pr.y-pr.h*.02,pr.w*.88,pr.h*.18);
      const w=pr.w*(t==='icecream-tub'?.95:.6);return rect(pr.x+pr.w*.01,pr.y-pr.h*.06,w,w*.62);
    }
    if(Object.values(packageChildren).includes(t)){
      if(!parent.open)return null;
      const s=itemSize(p,pr.w*.75,pr.h*.62);
      return rect(pr.x+pr.w*.35+(index%2)*s.w*.3,pr.y-pr.h*.08+Math.floor(index/2)*s.h*.22,s.w,s.h);
    }
    if(toolTypes.has(t)){const s=itemSize(p,pr.w*.72,pr.w*.7);return rect(pr.x-s.w*.2,pr.y-s.h*.5,s.w,s.h);}
    if(t==='cake-stand'){const w=pr.w*.84;return rect(pr.x+pr.w*.08,pr.y-pr.h*.5,w,w*.8);}
    if(t==='pizza-tray'&&p.type==='pizza-quarters'){
      const positions=[[.08,.08],[.5,.08],[.5,.5],[.08,.5]];const v=positions[p.index%4];return rect(pr.x+pr.w*v[0],pr.y+pr.h*v[1],pr.w*.42,pr.h*.42);
    }
    if(bowlTypes.has(t)){const s=itemSize(p,pr.w*.81,1000);return rect(pr.x+(pr.w-s.w)/2,pr.y+pr.h*.1,s.w,Math.min(s.h*.55,pr.h*.47));}
    if(panTypes.has(t)){const s=itemSize(p,pr.w*.55,1000);return rect(pr.x+pr.w*.02+(pr.w*.55-s.w)/2,pr.y+pr.h*.04+index*pr.h*.1,s.w,Math.min(s.h*.6,pr.h*.57));}
    const ratio=bowlTypes.has(t)?.78:panTypes.has(t)?(t==='pasta-pot'?.52:.55):.78;
    const s=itemSize(p,pr.w*ratio,pr.h*(bowlTypes.has(t)?.55:.78));
    return rect(pr.x+pr.w*(panTypes.has(t)?.02:.1)+(pr.w*ratio-s.w)/2,pr.y+pr.h*(bowlTypes.has(t)?.12:.12)+(pr.h*.56-s.h)/2+(count>1?index*pr.h*.12:0),s.w,s.h);
  }
  function buildPiece(p,r,parentNode,relativeTo=null){
    boxes.set(p.uid,r);const d=definition(p),n=$('div','kl-piece');n.dataset.uid=p.uid;n.dataset.type=p.type;n.setAttribute('role','button');n.tabIndex=0;n.setAttribute('aria-label',d.item+(p.warm?', warm':''));n.title=d.item;
    const local=relativeTo?rect(r.x-relativeTo.x,r.y-relativeTo.y,r.w,r.h):r;at(n,local);n.style.zIndex=String(p.order||8);
    if(state.selection===p.uid)n.classList.add('kl-selected');if(p.warm)n.classList.add('kl-ready');
    if(p.loc.kind==='station'&&p.loc.station==='toaster'&&p.justPopped>Date.now())n.classList.add('kl-pop');
    if(p.type==='tumbler'&&p.fill){const fluid=$('div','kl-fluid'),fill=$('div','kl-liquid-fill');fill.style.setProperty('--liquid',{milk:'#fff9df',orange:'#e9a42d',cola:'#5b2d13',soda:'#e0e1b577'}[p.fill]||'#fff9df');fluid.append(fill);n.append(fluid);}
    let sprite=p.type==='cake_slice'?'cake_slice':p.type;
    if(p.type==='egg-carton'&&p.open)sprite='eggcarton_open';
    if(p.type==='tumbler'&&p.ice>0)sprite='tumbler_ice';
    if(p.type==='turkey-roaster'&&p.loc.kind==='station'&&p.loc.station==='oven'&&children(p.uid).some(c=>c.type==='turkey'))sprite='turkey_oven';
    const img=svgSprite(sprite,p.index,['tumbler','milkshake'].includes(p.type));
    if(p.type==='milkshake'&&!p.fill)img.style.clipPath='inset(20% 0 0 0)';
    const art=asset(sprite,p.index);
    if((unitRoot(p)==='tools'||p.type==='turquoise-knife'&&unitRoot(p)==='cutlery')&&art&&art.cell[2]/art.cell[3]>1.8){img.style.inset='auto';img.style.width=r.h+'px';img.style.height=r.w+'px';img.style.left=((r.w-r.h)/2)+'px';img.style.top=((r.h-r.w)/2)+'px';img.style.transform='rotate(90deg)';}
    if(p.type==='pizza-quarters')img.style.transform='rotate('+(p.index*90)+'deg)';
    if(p.type==='birthday-cake'){
      const slices=children(p.uid).filter(x=>x.loc.kind==='cake').map(x=>x.index);
      if(slices.length<4){const segments=Array.from({length:4},(_,i)=>(slices.includes(i)?'#000':'transparent')+' '+(i*90)+'deg '+((i+1)*90)+'deg').join(',');img.style.maskImage='conic-gradient('+segments+')';}
    }
    n.append(img);
    if(p.type==='tumbler'&&p.ice&&p.fill){for(let i=0;i<Math.min(p.ice,5);i++){const cube=$('div','kl-glass-ice');at(cube,rect(r.w*(.18+(i%2)*.24),r.h*(.38+Math.floor(i/2)*.12),r.w*.35,r.w*.35));cube.append(svgSprite('ice_cube',i,true));n.append(cube);}}
    n.addEventListener('pointerdown',e=>piecePointer(e,p.uid));
    n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();activate(p.uid);}if(e.key==='Escape'){state.selection=null;dirty=true;}});
    n.addEventListener('mouseenter',()=>showTip(d.item,r));n.addEventListener('mouseleave',hideTip);
    parentNode.append(n);nodeMap.set(p.uid,n);
    const cs=children(p.uid).sort((a,b)=>a.order-b.order);cs.forEach((c,i)=>{const cr=childBox(c,r,i,cs.length);if(cr)buildPiece(c,cr,n,r);});return n;
  }
  function allAtStation(){const out=[];
    for(const [name,r] of Object.entries(stations)){
      if(name==='oven'&&!state.machines.oven.open)continue;
      if(name==='dispenser'&&state.open==='fridge')continue;
      const cs=stationContents(name);
      cs.forEach((p,i)=>{let s=itemSize(p,r.w*.92,r.h*.96);
        if(name.startsWith('burner')){s=itemSize(p,r.w*1.9,r.h*2.5);s.h*=.72;}
        if(name==='oven'&&p.type==='turkey-roaster'&&children(p.uid).some(c=>c.type==='turkey'))s={w:202,h:101};
        if(name==='oven'&&p.type==='pizza-tray'){s=itemSize(p,r.w*.94,1000);s.h*=.55;}
        let x=r.x+(r.w-s.w)/2,y=r.y+(r.h-s.h)/2;
        if(name==='toaster'){x=r.x+i*r.w*.5;y=state.machines.toaster.running?238:p.warm?199:217;}
        if(name==='blender'){if(state.machines.blender.blended)return;const size=23;x=r.x+16+(i%2)*20;y=r.y+r.h-42-Math.floor(i/2)*21;out.push([p,rect(x,y,size,size)]);return;}
        out.push([p,rect(x,y,s.w,s.h)]);
      });
    }return out;
  }
  function showTip(text,r){if(drag)return;tip.textContent=text;tip.hidden=false;tip.style.left=clamp(r.x,10,W-340)+'px';tip.style.top=clamp(r.y-36,8,H-50)+'px';}
  function hideTip(){tip.hidden=true;}
  function setOpen(unit){
    if(unit&&!units[unit])return false;
    const previous=state.open,next=unit===previous?null:unit;
    if(previous)sound(previous==='fridge'?'fridge.close':units[previous].drawer?'drawer.close':'cupboard.close');
    state.open=next;
    if(next)sound(next==='fridge'?'fridge.open':units[next].drawer?'drawer.open':'cupboard.open');
    say(next?units[next].name+' open. Choose a piece, then drag it or click where it goes.':'Storage closed.');
    state.selection=null;save();dirty=true;return true;
  }
  function hasLid(p){return children(p.uid).some(c=>c.loc.kind==='lid');}
  function activate(uid){
    const p=state.items[uid];if(!p)return;
    if(state.selection&&state.selection!==uid){const result=drop(state.selection,{kind:'item',uid});if(result){render();return;}}
    if(state.selection===uid&&(Object.values(packageChildren).includes(p.type)||p.type==='egg-carton'||p.type==='grape-jam')){
      p.open=!p.open;sound('box.open');say(definition(p).item+(p.open?' opened.':' closed.'));save();dirty=true;return;
    }
    if(canLids[p.type]&&state.selection===uid){say('Fit the closed can into the yellow can opener.');return;}
    state.selection=uid;say(definition(p).item+(Object.values(packageChildren).includes(p.type)||p.type==='egg-carton'||p.type==='grape-jam'?'. Click again to open, or drag it out.':'. Drag it, or choose its dish, appliance or storage home.'));dirty=true;
  }
  function openPackage(uid){const p=state.items[uid];if(!p)return false;p.open=true;save();dirty=true;return true;}
  function validInside(p,target){
    if(p.uid===target.uid||descendants(p.uid).includes(target.uid))return false;
    if(lids[p.type])return lids[p.type]===target.type;
    if(plateTypes.has(target.type))return foodTypes.has(p.type)||p.type==='cake_slice';
    if(bowlTypes.has(target.type))return ['salad-insert','vegetable-insert','grapefruit','popcorn-insert'].includes(p.type)&&!children(target.uid).some(x=>x.loc.kind==='inside');
    if(target.type==='cake-stand')return p.type==='birthday-cake'&&!children(target.uid).length;
    if(target.type==='birthday-cake')return p.type==='cake_slice';
    if(target.type==='turkey-roaster')return p.type==='turkey'||p.type==='chicken-drumsticks';
    if(target.type==='pizza-tray')return ['pizza-quarters','italian-pizza'].includes(p.type);
    if(target.type==='pasta-pot')return p.type==='spaghetti'||p.type==='vegetable-insert'||p.type==='corn-cob';
    if(target.type.startsWith('pink-saucepan'))return ['vegetable-insert','corn-cob'].includes(p.type);
    if(panTypes.has(target.type))return ['fried-eggs','bacon-piece','pancakes','french-toast','corn-cob','hotdog','burger','chicken-drumsticks'].includes(p.type);
    if(packageChildren[p.type]===target.type)return true;
    return false;
  }
  function pour(p,target){
    const liquid=liquids[p.type];if(!liquid)return false;
    if(target.type==='tumbler'||target.type==='pink-mug'){
      target.fill=liquid;state.selection=target.uid;sound('drink.pour');say(definition(target).item+' filled with '+({orange:'orange juice',soda:'lemon-lime soda'}[liquid]||liquid)+'.');save();dirty=true;return true;
    }
    return false;
  }
  function detachLid(can){const lid=children(can.uid).find(x=>x.loc.kind==='lid');if(!lid)return false;can.open=true;applyMove(lid.uid,{kind:'table',x:1090,y:770});sound('can.lid');return true;}
  function toolAction(tool,target){
    const carried=children(tool.uid).find(x=>x.loc.kind==='inside');
    if(carried){if(validInside(carried,target)){applyMove(carried.uid,{kind:'inside',parent:target.uid});say('Served onto '+definition(target).item+'.');sound('food.serve');return true;}return false;}
    if(tool.type==='ice-cream-scoop-tool'&&target.type==='icecream-tub'){
      if(hasLid(target)){say('Lift the ice-cream lid first.');return false;}
      const ball=children(target.uid).find(x=>x.type==='icecream-scoops');if(!ball){say('All three scoops are already out.');return false;}
      applyMove(ball.uid,{kind:'inside',parent:tool.uid});sound('icecream.scoop');say('A scoop is on the scooper. Take it to the open blender.');return true;
    }
    if(tool.type==='cake-server'&&target.type==='birthday-cake'){
      const slice=children(target.uid).find(x=>x.loc.kind==='cake');if(!slice)return false;
      applyMove(slice.uid,{kind:'inside',parent:tool.uid});sound('cake.serve');say('Cake slice lifted. Choose its dessert plate.');return true;
    }
    if(tool.type==='pizza-cutter'&&target.type==='pizza-tray'){
      if(!children(target.uid).some(x=>x.type==='pizza-quarters'))return false;
      target.cut=true;sound('pizza.cut');say('Pizza quarters are ready to lift out and serve.');save();dirty=true;return true;
    }
    if(['pink-spatula','green-serving-spoon','pink-cooking-spoon'].includes(tool.type)&&panTypes.has(target.type)){
      const portion=children(target.uid).find(x=>x.loc.kind==='inside'&&foodTypes.has(x.type));if(!portion)return false;
      applyMove(portion.uid,{kind:'inside',parent:tool.uid});sound('food.serve');say('Food lifted. Choose a plate or bowl.');return true;
    }
    return false;
  }
  function drop(uid,target){
    const p=state.items[uid];if(!p)return false;
    if(target.kind==='table'){
      applyMove(uid,{kind:'table',x:clamp(target.x,10,W-itemSize(p).w-10),y:clamp(target.y,697,H-itemSize(p).h-46)});sound(definition(p).sound_keys.find(x=>x.startsWith('place.'))||'place.food');return true;
    }
    if(target.kind==='counter'){
      const s=itemSize(p),left=target.x<850?550:1125,right=target.x<850?838:1570;
      if(s.w>right-left){say('Use the gingham table for this large piece.');return false;}
      applyMove(uid,{kind:'counter',x:clamp(target.x,left,right-s.w),y:349-s.h});sound('place.food');return true;
    }
    if(target.kind==='home'){
      if(p.home!==target.unit){say('This belongs in '+(units[p.home]?.name||'its own storage home')+'.');return false;}
      if(toolTypes.has(p.type)&&children(p.uid).some(x=>x.loc.kind==='inside')){say('Put the food on a dish before storing the tool.');return false;}
      applyMove(uid,{kind:'home',unit:p.home});say(definition(p).item+' put away.');return true;
    }
    if(target.kind==='station'){
      const name=target.station;
      if(name.startsWith('burner')){
        if(!panTypes.has(p.type)||['pizza-tray','turkey-roaster'].includes(p.type)){say('Put a frying pan, griddle or saucepan on the burner.');return false;}
        if(stationContents(name).some(x=>x.uid!==uid)){say('That burner already has a pan.');return false;}
      }else if(name==='oven'){
        if(!state.machines.oven.open){say('Open the oven door first.');return false;}
        if(!['turkey-roaster','pizza-tray','frozen-dinner'].includes(p.type)){say('The roaster, pizza tray or frozen-dinner tray fits here.');return false;}
        if(stationContents('oven').some(x=>x.uid!==uid)){say('There is already a tray in the oven.');return false;}
      }else if(name==='toaster'){
        if(!['toast','frozen-waffles'].includes(p.type)){say('The toast pieces and waffles fit the toaster.');return false;}
        if(state.machines.toaster.running||stationContents('toaster').length>=2){say('The toaster has two slots.');return false;}
      }else if(name==='blender'){
        const m=state.machines.blender;
        if(m.lid){say('Open the blender lid first.');return false;}
        if(liquids[p.type]==='milk'){m.milk=true;sound('drink.pour');say('Milk added to the blender.');save();dirty=true;return true;}
        if(p.type==='ice-cream-scoop-tool'){
          const ball=children(uid).find(x=>x.type==='icecream-scoops');if(!ball){say('Use the scooper to lift a ball from the tub.');return false;}return drop(ball.uid,target);
        }
        if(p.type!=='icecream-scoops'){say('This shake uses the three ice-cream balls and milk.');return false;}
        if(m.blended||stationContents('blender').length>=3)return false;
      }else if(name==='opener'){
        if(!canLids[p.type]){say('The peach, corn and SpaghettiOs cans fit this opener.');return false;}
        if(stationContents('opener').length&&stationContents('opener')[0].uid!==uid)return false;
      }else if(name==='dispenser'){
        if(p.type!=='tumbler'){say('Put the clear tumbler under the ice lever.');return false;}
        if(state.open==='fridge'){say('Close the fridge to use its dispenser.');return false;}
      }else return false;
      applyMove(uid,{kind:'station',station:name});sound('place.metal');say(definition(p).item+' placed.');return true;
    }
    if(target.kind==='item'){
      const dest=state.items[target.uid];if(!dest||dest.uid===uid)return false;
      if(pour(p,dest))return true;
      if(toolTypes.has(p.type)&&toolAction(p,dest))return true;
      if(dest.type==='birthday-cake'&&p.type==='cake_slice'){applyMove(uid,{kind:'cake',parent:dest.uid});say('Cake slice put back.');return true;}
      if(validInside(p,dest)){
        const lid=!!lids[p.type];if(!lid&&hasLid(dest)){say('Lift the matching lid first.');return false;}
        applyMove(uid,{kind:lid?'lid':'inside',parent:dest.uid});
        if(lid)dest.open=false;else if(packageChildren[p.type]===dest.type)dest.open=true;
        sound(lid?'lid.metal':'food.fit');say(definition(p).item+(lid?' fits its matching lid position.':' placed in '+definition(dest).item+'.'));return true;
      }
      say('Choose a dish, pan or container that fits this piece.');return false;
    }
    return false;
  }
  function rootPoint(event){const r=world.getBoundingClientRect();return {x:(event.clientX-r.left)*W/r.width,y:(event.clientY-r.top)*H/r.height};}
  function hitTarget(point,uid){
    const candidates=[...boxes.entries()].filter(([id,r])=>id!==uid&&!descendants(uid).includes(id)&&point.x>=r.x&&point.x<=r.x+r.w&&point.y>=r.y&&point.y<=r.y+r.h).sort((a,b)=>(state.items[b[0]].order||0)-(state.items[a[0]].order||0));
    for(const [id] of candidates){const p=state.items[id];if(containerTypes.has(p.type)||liquids[state.items[uid].type]||p.type==='birthday-cake')return {kind:'item',uid:id};}
    for(const [name,r] of Object.entries(stations))if(point.x>=r.x&&point.x<=r.x+r.w&&point.y>=r.y&&point.y<=r.y+r.h)return {kind:'station',station:name};
    if(state.open&&state.open!=='fridge'){
      const r=units[state.open].r;if(point.x>=r.x&&point.x<=r.x+r.w&&point.y>=r.y&&point.y<=r.y+r.h)return {kind:'home',unit:state.open};
    }
    if(state.open==='fridge'&&point.x<540&&point.y<660)return {kind:'home',unit:'fridge'};
    if(point.y>=305&&point.y<=369&&(point.x>=550&&point.x<=838||point.x>=1125&&point.x<=1570))return {kind:'counter',x:point.x};
    if(point.y>=692&&point.y<965)return {kind:'table',x:point.x,y:point.y};
    return null;
  }
  function piecePointer(e,uid){
    if(e.button!==0)return;e.stopPropagation();e.preventDefault();hideTip();
    const point=rootPoint(e),r=boxes.get(uid);if(!r)return;
    selectedBeforeDrag=state.selection;drag={uid,id:e.pointerId,start:point,point,r,started:false,offset:{x:point.x-r.x,y:point.y-r.y}};
    world.setPointerCapture(e.pointerId);
  }
  function pointerMove(e){
    if(!drag||drag.id!==e.pointerId)return;const p=rootPoint(e);drag.point=p;
    if(!drag.started&&Math.hypot(p.x-drag.start.x,p.y-drag.start.y)>7){
      drag.started=true;state.selection=drag.uid;const original=nodeMap.get(drag.uid),ghost=original.cloneNode(true);ghost.classList.remove('kl-selected');ghost.classList.add('kl-ghost');ghost.style.zIndex='80000';ghost.querySelectorAll('[tabindex]').forEach(n=>n.removeAttribute('tabindex'));world.append(ghost);drag.ghost=ghost;original.classList.add('kl-moving');
    }
    if(drag.ghost){drag.ghost.style.left=(p.x-drag.offset.x)+'px';drag.ghost.style.top=(p.y-drag.offset.y)+'px';}
  }
  function pointerUp(e){
    if(!drag||drag.id!==e.pointerId)return;const d=drag;drag=null;d.ghost?.remove();nodeMap.get(d.uid)?.classList.remove('kl-moving');
    if(d.started){const target=hitTarget(d.point,d.uid);if(target){if(target.kind==='table'){target.x-=d.offset.x;target.y-=d.offset.y;}drop(d.uid,target);}else say('Place the piece on the table, in its storage home, or in a matching container.');}
    else {state.selection=selectedBeforeDrag;activate(d.uid);}
    suppressWorldClickUntil=performance.now()+80;dirty=true;render();
  }
  function toggleLid(){const m=state.machines.blender;if(m.running)return;m.lid=!m.lid;sound('blender.lid');say('Blender lid '+(m.lid?'closed.':'open.'));save();dirty=true;}
  function startBlender(){
    const m=state.machines.blender;
    if(m.blended){pourShake();return;}
    if(m.running){m.running=false;stopSound('blender.run');sound('blender.stop');save();dirty=true;return;}
    if(!m.lid){say('Close the blender lid before blending.');return;}
    if(!m.milk||stationContents('blender').length<1){say('Add milk and ice-cream scoops to the open jar first.');return;}
    m.running=true;m.remaining=3500;sound('blender.start');sound('blender.run',true);say('Blending the milkshake.');save();dirty=true;
  }
  function pourShake(){
    const m=state.machines.blender,p=state.items[state.selection];
    if(!m.blended)return false;
    if(!p||p.type!=='milkshake'){say('Choose the tall empty shake glass, then touch the blender control to pour.');return false;}
    if(p.fill){say('The shake glass is already full.');return false;}
    p.fill='shake';m.blended=false;m.milk=false;
    for(const ball of stationContents('blender'))ball.loc={kind:'batch',parent:p.uid};
    sound('drink.pour');say('Milkshake poured into its own glass.');save();dirty=true;return true;
  }
  function startToaster(){const m=state.machines.toaster;if(m.running)return;if(!stationContents('toaster').length){say('Load toast pieces or waffles into the two slots first.');return;}m.running=true;m.remaining=3000;sound('toaster.lever');say('Toaster lever down.');save();dirty=true;}
  function toggleBurner(index){const on=state.machines.burners[index]=!state.machines.burners[index];sound('stove.on');if(on)sound('stove.sizzle',true);else if(!state.machines.burners.some(Boolean))stopSound('stove.sizzle');say('Burner '+(index+1)+(on?' on.':' off.'));save();dirty=true;}
  function toggleOven(){const m=state.machines.oven;m.open=!m.open;sound(m.open?'oven.open':'oven.close');say('Oven door '+(m.open?'open.':'closed.'));save();dirty=true;}
  function startOven(){const m=state.machines.oven;if(m.open){say('Close the oven door first.');return;}if(!stationContents('oven').length){say('Put the roaster, pizza tray or frozen meal into the oven first.');return;}m.running=true;m.remaining=12000;sound('oven.timer');say('Oven timer set.');save();dirty=true;}
  function operateCan(){const p=stationContents('opener')[0];if(!p){say('Slot a peach, corn or SpaghettiOs can into the yellow opener.');return;}state.machines.opener.open=true;sound('canopener.lever');if(detachLid(p)){sound('canopener.open');say('Can opened. The matching lid is on the table.');}else say('This can is already open.');save();dirty=true;}
  function dispense(){if(state.open==='fridge'){say('Close the fridge to use the ice dispenser.');return;}const glass=stationContents('dispenser').find(p=>p.type==='tumbler');if(!glass){say('Put the clear glass under the dispenser lever first.');return;}glass.ice=clamp(glass.ice+1,0,5);sound('fridge.ice');say('Clear toy ice drops into the glass.');save();dirty=true;render();const n=$('div','kl-falling-ice');at(n,rect(189,290,25,25));n.append(svgSprite('ice_cube',0,true));world.append(n);setTimeout(()=>n.remove(),600);}
  let popcornEnergy=0,popcornAngle=0,popcornHeld=false,popcornPoint=null,popcornMotionUntil=0;
  const beads=Array.from({length:45},(_,i)=>({x:30+(i%10)*11+Math.sin(i*9)*3,y:94-Math.floor(i/10)*5,vx:0,vy:0}));
  function crankDown(e){e.preventDefault();e.stopPropagation();popcornHeld=true;popcornPoint=rootPoint(e);e.currentTarget.setPointerCapture(e.pointerId);crank(1);}
  function crank(amount){popcornEnergy=clamp(popcornEnergy+amount,0,10);popcornAngle+=amount*35;popcornMotionUntil=performance.now()+5000;state.machines.popcorn.turns+=amount;sound('popcorn.crank',true);sound('popcorn.pop',true);}
  function crankMove(e){if(!popcornHeld)return;const p=rootPoint(e),distance=Math.hypot(p.x-popcornPoint.x,p.y-popcornPoint.y);if(distance>1){crank(distance/25);popcornPoint=p;}}
  function crankUp(){popcornHeld=false;popcornPoint=null;stopSound('popcorn.crank');save();}
  function drawPopcorn(dt){
    const canvas=world?.querySelector('.kl-popcorn-canvas');if(!canvas)return;const ctx=canvas.getContext('2d');ctx.clearRect(0,0,180,130);ctx.save();ctx.beginPath();ctx.ellipse(90,62,67,58,0,Math.PI,Math.PI*2);ctx.lineTo(157,98);ctx.lineTo(23,98);ctx.closePath();ctx.clip();
    const moving=popcornEnergy>.05;
    for(let i=0;i<beads.length;i++){const b=beads[i];if(moving&&Math.random()<popcornEnergy*.015){b.vy=-50-Math.random()*95;b.vx=(Math.random()-.5)*55;}b.vy+=dt*150;b.x+=b.vx*dt;b.y+=b.vy*dt;
      const floor=94-Math.floor(i/10)*5;if(b.y>floor){b.y=floor;b.vy*=-.18;b.vx*=.7;}b.x=clamp(b.x,28,151);
      const g=ctx.createRadialGradient(b.x-2,b.y-2,.1,b.x,b.y,4.5);g.addColorStop(0,'#fff');g.addColorStop(1,'#dbd8cf');ctx.fillStyle=g;ctx.beginPath();ctx.arc(b.x,b.y,4.5,0,Math.PI*2);ctx.fill();
    }ctx.restore();popcornEnergy=Math.max(0,popcornEnergy-dt*3);if(!moving)stopSound('popcorn.pop');
    const handle=world.querySelector('[data-crank-art]');if(handle)handle.style.transform='rotate('+(90+popcornAngle)+'deg)';
  }
  function tick(now){raf=0;if(!active)return;if(!lastTime)lastTime=now;const elapsed=Math.min(150,now-lastTime),dt=elapsed/1000;lastTime=now;
    const toaster=state.machines.toaster,blender=state.machines.blender,oven=state.machines.oven;
    if(toaster.running){toaster.remaining-=elapsed;if(toaster.remaining<=0){toaster.running=false;stationContents('toaster').forEach(p=>{p.warm=true;p.justPopped=Date.now()+650;});sound('toaster.pop');say('Pop! Toast or waffles are ready.');dirty=true;save();}}
    if(blender.running){blender.remaining-=elapsed;if(blender.remaining<=0){blender.running=false;blender.blended=true;stopSound('blender.run');sound('blender.stop');say('Shake blended. Choose its empty tall glass, then touch the blender control to pour.');dirty=true;save();}}
    if(oven.running&&!oven.open){oven.remaining-=elapsed;if(oven.remaining<=0){oven.running=false;stationContents('oven').forEach(p=>{p.warm=true;descendants(p.uid).forEach(id=>state.items[id].warm=true);});sound('oven.done');say('Ding! The oven meal is ready.');dirty=true;save();}}
    state.machines.burners.forEach((on,i)=>{if(on)stationContents('burner'+i).forEach(p=>{p.heat=(p.heat||0)+elapsed;if(p.heat>=4000&&!p.warm){p.warm=true;descendants(p.uid).forEach(id=>state.items[id].warm=true);say('Food is warm and ready to serve.');dirty=true;save();}});});
    const redraw=dirty&&!drag;if(redraw)render();if(popcornEnergy>.01||now<popcornMotionUntil||redraw)drawPopcorn(dt);raf=requestAnimationFrame(tick);
  }
  function pageControl(key,list,size,r,label){const pg=pageFor(list,key,size);if(pg.count<=1)return;
    const wrap=$('div','kl-page-control');at(wrap,r);
    const prev=$('button','','‹'),next=$('button','','›'),text=$('span','',(pg.page+1)+'/'+pg.count);
    prev.type=next.type='button';prev.disabled=pg.page===0;next.disabled=pg.page===pg.count-1;prev.setAttribute('aria-label','Previous '+label);next.setAttribute('aria-label','Next '+label);
    prev.onclick=()=>{state.pages[key]--;dirty=true;save();};next.onclick=()=>{state.pages[key]++;dirty=true;save();};wrap.append(prev,text,next);world.append(wrap);
  }
  function actionHotspots(){
    for(const [id,u] of Object.entries(units)){const button=makeButton(u.name,u.hit,()=>{if(state.selection&&state.open===id&&state.items[state.selection]?.home===id){drop(state.selection,{kind:'home',unit:id});}else setOpen(id);});button.dataset.storage=id;button.setAttribute('aria-expanded',String(state.open===id));world.append(button);}
    const m=state.machines;
    world.append(makeButton('Open or close oven',rect(865,400,236,184),()=>{if(state.selection&&m.oven.open){drop(state.selection,{kind:'station',station:'oven'});}else toggleOven();}));
    for(let i=0;i<4;i++){const b=makeButton('Burner '+(i+1),rect(870+i*58,360,39,39),()=>toggleBurner(i));if(m.burners[i])b.classList.add('kl-knob-on');world.append(b);}
    world.append(makeButton('Set oven timer',rect(1030,240,40,35),startOven));
    world.append(makeButton('Toaster lever',rect(818,279,28,40),startToaster));
    world.append(makeButton('Blender lid',rect(1150,128,144,50),toggleLid));
    world.append(makeButton('Blender control / pour shake',rect(1150,311,140,40),startBlender));
    world.append(makeButton('Blender jar',stations.blender,()=>{if(state.selection)drop(state.selection,{kind:'station',station:'blender'});else toggleLid();}));
    world.append(makeButton('Can-opener lever',rect(575,219,90,45),operateCan));
    world.append(makeButton('Can-opener slot',stations.opener,()=>{if(state.selection)drop(state.selection,{kind:'station',station:'opener'});else operateCan();}));
    if(state.open!=='fridge'){
      world.append(makeButton('Place glass under dispenser',rect(158,303,106,115),()=>{if(state.selection)drop(state.selection,{kind:'station',station:'dispenser'});}));
      world.append(makeButton('Ice dispenser lever',rect(158,244,106,58),dispense));
    }
    world.append(makeButton('Load toaster',rect(678,230,138,45),()=>{if(state.selection)drop(state.selection,{kind:'station',station:'toaster'});else startToaster();}));
    Object.entries(stations).filter(([name])=>name.startsWith('burner')).forEach(([name,r])=>world.append(makeButton('Place pan on '+name,r,()=>{if(state.selection)drop(state.selection,{kind:'station',station:name});})));
    const crankButton=makeButton('Turn the popcorn crank',rect(1400,294,58,70),()=>{});crankButton.addEventListener('pointerdown',crankDown);crankButton.addEventListener('pointermove',crankMove);for(const type of ['pointerup','pointercancel','lostpointercapture'])crankButton.addEventListener(type,crankUp);world.append(crankButton);
  }
  function appliance(name,source,r,glass=false){const n=$('div','kl-appliance');at(n,r);n.dataset.appliance=name;n.append(svgSprite(source,0,glass));world.append(n);return n;}
  function render(){
    if(!world)return;dirty=false;hideTip();nodeMap.clear();boxes.clear();
    world.replaceChildren();const bg=$('img','kl-background');bg.alt='Warm wooden kitchen and overhead blue gingham play table';bg.src=backgroundUrl;world.append(bg);
    const filter=document.createElementNS(NS,'svg');filter.style.position='absolute';filter.style.width='0';filter.style.height='0';filter.setAttribute('aria-hidden','true');
    filter.innerHTML='<defs><filter id="kl-solid-alpha"><feComponentTransfer><feFuncA type="gamma" amplitude="1" exponent="5" offset="0"/></feComponentTransfer></filter><filter id="kl-glass-alpha"><feComponentTransfer><feFuncA type="gamma" amplitude="1" exponent="2" offset="0"/></feComponentTransfer></filter></defs>';world.append(filter);
    appliance('fridge',state.open==='fridge'?'fridge_open':'fridge',state.open==='fridge'?fixed.fridgeOpen:fixed.fridge);
    appliance('stove',state.machines.oven.open?'stove_open':'stove',fixed.stove);
    appliance('toaster','toaster_body',rect(665,231,152,111));
    appliance('blender',state.machines.blender.lid?'blender':'blender_open',state.machines.blender.lid?fixed.blender:rect(1150,160,147,185),true);
    if(state.machines.blender.milk){const fill=$('div');at(fill,rect(1171,241-(state.machines.blender.blended?39:0),62,state.machines.blender.blended?92:48));fill.style.background='linear-gradient(90deg,#e8e0c9,#fff7df,#e8e0c9)';fill.style.borderRadius='15% 15% 10% 10%';fill.style.position='absolute';fill.style.zIndex='3';world.append(fill);}
    appliance('popcorn','popcorn_empty',fixed.popcorn,true);
    appliance('opener',state.machines.opener.open?'opener_open':'opener',fixed.opener);
    if(!state.machines.blender.lid){const lid=appliance('blender lid','blender_lid',rect(1267,306,64,36));lid.style.zIndex='5';}
    const crankArt=appliance('popcorn crank','popcorn_crank',rect(1408,306,55,31));crankArt.dataset.crankArt='true';crankArt.style.transformOrigin='10% 50%';crankArt.style.zIndex='5';
    const canvas=$('canvas','kl-popcorn-canvas');canvas.width=180;canvas.height=130;at(canvas,rect(1337,198,177,113));world.append(canvas);
    if(state.open&&state.open!=='fridge'){
      const u=units[state.open],interior=$('div','kl-open-storage'+(u.drawer?' kl-drawer':''));at(interior,u.r);world.append(interior);
      const title=$('div','kl-storage-title',u.name);title.style.left=u.r.x+'px';title.style.top=(u.r.y-28)+'px';world.append(title);
      pageControl(state.open,rootsIn(state.open),u.pageSize,rect(u.r.x,u.r.y+u.r.h+14,u.r.w,32),'Shelf');
    }else if(state.open==='fridge'){
      const all=rootsIn('fridge');pageControl('fridge-frozen',all.filter(p=>frozenTypes.has(p.type)),3,rect(58,619,220,32),'Frozen');pageControl('fridge-cold',all.filter(p=>!frozenTypes.has(p.type)),6,rect(296,619,220,32),'Chilled');
    }
    actionHotspots();
    for(const [p,r] of homePlacements())buildPiece(p,r,world);
    for(const p of Object.values(state.items).filter(p=>p.loc.kind==='table'||p.loc.kind==='counter').sort((a,b)=>a.order-b.order)){const s=itemSize(p);buildPiece(p,rect(p.loc.x,p.loc.y,s.w,s.h),world);}
    for(const [p,r] of allAtStation())buildPiece(p,r,world);
    const toasterFront=appliance('toaster front','toaster_body',rect(665,231,152,111));toasterFront.style.clipPath='inset(26% 0 0 0)';toasterFront.style.zIndex='7500';
    const lever=appliance('toaster lever','toaster_lever',rect(814,state.machines.toaster.running?302:286,24,24));lever.style.zIndex='7500';
    if(state.machines.oven.running){const glow=$('div','kl-oven-glow');at(glow,rect(877,441,214,119));world.append(glow);}
    state.machines.burners.forEach((on,i)=>{if(on&&stationContents('burner'+i).length){const r=stations['burner'+i],steam=$('div','kl-heat');at(steam,rect(r.x+30,r.y-35,50,50));steam.innerHTML='<i></i><i></i><i></i>';world.append(steam);}});
    if(state.machines.blender.running)world.querySelector('[data-appliance=blender]')?.classList.add('kl-bubbling');
    const status=$('div','kl-status');message.textContent=lastMessage;const tidy=$('button','','Tidy up');tidy.type='button';tidy.onclick=()=>reset();status.append(message,tidy);world.append(status,tip);tip.hidden=true;drawPopcorn(0);
  }
  function reset(){const pos=state.window;state=initial();state.window=pos;stopAllSounds();popcornEnergy=0;popcornMotionUntil=0;beads.forEach((b,i)=>{b.y=94-Math.floor(i/10)*5;b.vx=b.vy=0;});say('Everything is back in its own place.');persist();dirty=true;render();}
  function verify(){const issues=[],all=Object.values(state.items);for(const p of all){if(p.loc.parent&&!state.items[p.loc.parent])issues.push('Missing parent '+p.uid);if(p.loc.kind==='home'&&!units[p.loc.unit])issues.push('Invalid storage '+p.uid);const seen=new Set([p.uid]);let v=p;while(v.loc.parent){if(seen.has(v.loc.parent)){issues.push('Container cycle '+p.uid);break;}seen.add(v.loc.parent);v=state.items[v.loc.parent];if(!v)break;}}return {ok:!issues.length,issues,inventoryEntries:DATA.plan.items.length,movableInstances:all.filter(x=>x.type!=='cake_slice').length,cakePortions:all.filter(x=>x.type==='cake_slice').length,openStorage:state.open,foodCount:all.filter(x=>foodTypes.has(x.type)).length};}
  function layout(){
    if(!root||!surface)return;
    const sr=surface.getBoundingClientRect(),scale=sr.width/W;world.style.transform='scale('+scale+','+(sr.height/H)+')';
    world.style.setProperty('--kl-text',Math.max(18,11/Math.max(.15,scale))+'px');world.style.setProperty('--kl-arrow',Math.max(28,18/Math.max(.15,scale))+'px');
  }
  function activity(){active=opened&&!root.hidden&&!document.hidden;cancelAnimationFrame(raf);raf=0;lastTime=0;if(active){dirty=true;layout();raf=requestAnimationFrame(tick);}else{stopAllSounds();crankUp();persist();}}
  function mount(parent,options={}){
    if(root)return root;harness=!!options.harness;root=$('section');root.id='caseyKitchen';root.setAttribute('role','dialog');root.setAttribute('aria-label','Kitchen Littles');root.hidden=true;
    frameArt=options.frame||null;frameGeometry=options.geometry||null;
    surface=$('div','kl-surface');surface.style.zIndex='1';world=$('div','kl-world');surface.append(world);root.append(surface);
    const sr=$('div','kl-sr');sr.setAttribute('role','status');sr.setAttribute('aria-live','polite');root.append(sr);
    backgroundUrl=DATA.assets.atlas[DATA.assets.background].url;
    if(frameArt){const image=$('img','kl-artwork');image.src=frameArt;image.alt='Approved purple Kitchen Littles window frame';root.prepend(image);}
    if(harness){root.style.width='792px';root.style.height='497px';root.style.left='0';root.style.top='0';surface.style.inset='0';}
    else if(frameGeometry){surface.style.left=frameGeometry.left+'%';surface.style.top=frameGeometry.top+'%';surface.style.width=frameGeometry.width+'%';surface.style.height=frameGeometry.height+'%';}
    parent.append(root);world.addEventListener('pointermove',pointerMove);world.addEventListener('pointerup',pointerUp);world.addEventListener('pointercancel',e=>{if(drag){drag.ghost?.remove();drag=null;dirty=true;}});
    world.addEventListener('click',e=>{if(performance.now()<suppressWorldClickUntil)return;if(e.target!==world&&!e.target.classList.contains('kl-background'))return;if(state.selection){const p=rootPoint(e),target=hitTarget(p,state.selection);if(target)drop(state.selection,target);else state.selection=null;dirty=true;}});
    root.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){if(state.selection){state.selection=null;dirty=true;}else if(state.open)setOpen(state.open);}});
    for(const t of ['keyup','keypress'])root.addEventListener(t,e=>e.stopPropagation());
    document.addEventListener('visibilitychange',activity);window.addEventListener('resize',layout);window.addEventListener('pagehide',persist);if(window.ResizeObserver)new ResizeObserver(layout).observe(surface);
    render();return root;
  }
  function show(){if(!root)return;opened=true;root.hidden=false;activity();}
  function hide(){if(!root)return;root.hidden=true;activity();}
  function close(){opened=false;hide();}
  function setFrame(url,geometry){frameArt=url;frameGeometry=geometry;root?.querySelector('.kl-artwork')?.remove();if(root){const im=$('img','kl-artwork');im.src=url;root.prepend(im);surface.style.left=geometry.left+'%';surface.style.top=geometry.top+'%';surface.style.width=geometry.width+'%';surface.style.height=geometry.height+'%';layout();}}
  window.CaseyKitchen={mount,show,hide,close,layout,setFrame,reset,verify,
    getState:()=>copy(state),getCatalog:()=>copy(DATA.plan.items),getBoxes:()=>Object.fromEntries(boxes),getData:()=>DATA,
    setWindowPosition:(x,y)=>{state.window={x:clamp(x,0,1),y:clamp(y,0,1)};save();},
    setSounds:map=>{sounds=Object.assign({},map);},
    actions:{open:setOpen,select:uid=>{state.selection=uid;dirty=true;},drop,package:openPackage,toaster:startToaster,ovenDoor:toggleOven,oven:startOven,burner:toggleBurner,blenderLid:toggleLid,blend:startBlender,pourShake,can:operateCan,ice:dispense,crank,save:persist,render},
    setTestClock:ms=>{for(const m of [state.machines.toaster,state.machines.oven,state.machines.blender])if(m.running)m.remaining=ms;},
    dispose:()=>{opened=false;active=false;cancelAnimationFrame(raf);clearTimeout(saveTimer);stopAllSounds();persist();root?.remove();root=null;}
  };
})();
