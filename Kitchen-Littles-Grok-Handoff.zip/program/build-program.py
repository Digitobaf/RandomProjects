from pathlib import Path
import base64,json

ROOT=Path(__file__).parent
assets=json.loads((ROOT/'ASSETS.json').read_text())
for a in assets['atlas'].values():
    source=Path(a.pop('path'))
    if not source.is_absolute():source=ROOT/source
    a['url']='data:image/webp;base64,'+base64.b64encode(source.read_bytes()).decode()
plan=json.loads((ROOT.parent/'PLAN.json').read_text())
data={'assets':assets,'plan':plan}
frame_config=ROOT/'frame-config.json'
if frame_config.exists():
    frame=json.loads(frame_config.read_text())
    if frame.get('approved_original') is not True:raise RuntimeError('Frame must be the original user-approved artwork.')
    source=Path(frame.pop('path'))
    if not source.is_absolute():source=ROOT/source
    mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'}[source.suffix.lower()]
    frame['url']='data:'+mime+';base64,'+base64.b64encode(source.read_bytes()).decode()
    data['frame']=frame
js=(ROOT/'kitchen.js').read_text().replace('__KITCHEN_DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c'))
css=(ROOT/'kitchen.css').read_text()
(ROOT/'kitchen.compiled.js').write_text(js)
desktop=(ROOT/'desktop.js').read_text()
fragment='<style id="caseyKitchenStyles">\n'+css+'\n</style>\n<script id="caseyKitchenProgram">\n'+js+'\n</script>\n<script id="caseyKitchenDesktop">\n'+desktop+'\n</script>\n'
(ROOT/'program-fragment.html').write_text(fragment)
harness='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kitchen Littles — internal gameplay preview</title><style>html,body{margin:0;background:#f7edd9;min-height:100%;}#preview{position:relative;width:min(100vw,1100px);aspect-ratio:1584/993;margin:auto;}#caseyKitchen{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;}</style></head><body><main id="preview"></main>'+fragment+'<script>CaseyKitchen.mount(document.getElementById("preview"),{harness:true});CaseyKitchen.show();</script></body></html>'
(ROOT/'harness.html').write_text(harness)
print(json.dumps({'item_entries':len(plan['items']),'compiled_bytes':len(js.encode()),'harness_bytes':len(harness.encode()),'approved_frame_pending':'frame' not in data}))
