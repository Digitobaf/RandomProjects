from pathlib import Path
import argparse,hashlib,json

ROOT=Path(__file__).parent
REPO=ROOT.parent
MAIN=REPO/'Caseys-Room-with-Mood-Ring.html'
START='<!-- BEGIN CASEY KITCHEN LITTLES PROGRAM -->'
END='<!-- END CASEY KITCHEN LITTLES PROGRAM -->'

def integrate(fixture=False):
    baseline=MAIN.read_text()
    assert START not in baseline,'Kitchen block already exists; update it deliberately rather than duplicate it.'
    fragment=(ROOT/'program-fragment.html').read_text()
    if not fixture and not (ROOT/'frame-config.json').exists():
        raise RuntimeError('The exact approved window artwork is still required; canonical app remains unchanged.')
    setup=''
    if fixture:
        # Invisible geometry fixture, strictly for lifecycle/desktop tests, never delivered.
        frame={'url':'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="800" height="600"/%3E',
               'width':800,'height':600,'preferredWidth':620,
               'content':{'left':1,'top':11,'width':98,'height':87},
               'minimize':{'left':89,'top':2,'width':4,'height':6},
               'close':{'left':94,'top':2,'width':4,'height':6},
               'drag':{'left':20,'top':0,'width':65,'height':9}}
        setup='<script>CaseyKitchen.attachDesktop('+json.dumps(frame)+');</script>\n'
    block=START+'\n'+fragment+setup+END+'\n'
    index=baseline.rfind('</body>');assert index>=0
    output=baseline[:index]+block+baseline[index:]
    assert output.replace(block,'',1)==baseline
    target=ROOT/'integration-check.html' if fixture else MAIN
    target.write_text(output)
    metadata={'fixture':fixture,'baseline_sha256':hashlib.sha256(baseline.encode()).hexdigest(),'output_sha256':hashlib.sha256(output.encode()).hexdigest(),'only_new_program_block_added':True,'existing_programs_byte_identical':True,'bytes':len(output.encode())}
    (ROOT/('integration-fixture.json' if fixture else 'integration.json')).write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps(metadata))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--check-fixture',action='store_true');args=parser.parse_args();integrate(args.check_fixture)
