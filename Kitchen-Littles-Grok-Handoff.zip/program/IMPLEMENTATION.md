# Kitchen Littles implementation checkpoint

The user explicitly authorized writing the program after requesting a full food audit and drawers for cutlery and cooking tools. This supersedes the earlier asset-collection-only scope. Finish the independent program and integrate it into Casey’s Room using the repository’s normal ZIP / GitHub delivery workflow when the original approved frame is available. Do not ask for implementation permission again.

## Current build

- `kitchen.js` and `kitchen.css`: gameplay, pointer/keyboard item selection, drag/drop, storage, dishes/containers, recipe states, toy animation, save/restore, and lifecycle handling.
- `desktop.js`: isolated desktop icon, Start menu entry, taskbar item, window dragging, minimize/restore and close controls. The actual frame is required for production mounting.
- 98 catalogue entries: six fixed appliances and 92 movable item types. They expand to 105 movable instances plus four conserved cake segments. All reference sets are covered in `../FOOD-ACCOUNTING.md` and `reference-accounting.json`.
- A divided cutlery drawer above the left cooking cupboard, and a cooking/serving-tools drawer above the baking cupboard. Both participate in the same global one-open-storage rule as the fridge and five cupboards.
- Artwork uses format-only WebP copies of the existing generated sheets, with SVG atlas viewports and paint-time alpha filtering. Original PNGs are untouched. Every catalogue item has an explicit sprite mapping, scale and storage home.
- Popcorn serving bowl, insert and packet were found missing during the audit and are now included. They are separate from the machine’s enclosed mechanism beads.
- The game is silent until the user supplies its sound files. Event cue hooks are implemented; no replacement audio has been synthesized or borrowed from other programs.

## Validation

- `qa.py` runs 14 meaningful core playthrough checks: all inventory assets, exclusive storage including drawers, real pointer selection/drag, container/food relationships, pasta, toaster, oven, pizza, cake, milkshakes, cans/lids, ice, popcorn, save/reload, pause/resume, offline media and small window bounds. Results: `qa-results.json`.
- Desktop shell launch, minimize/restore, close/taskbar removal, window dragging/bounds, Start menu launch and preservation of game state passed. Results: `desktop-qa.json`.
- Desktop tests use an invisible geometry fixture only, never a substitute design for the approved frame. `integrate.py --check-fixture` builds that temporary fixture. Existing Casey’s Room code is byte-identical after removing the appended Kitchen block; see `integration-fixture.json`.
- Final rendering still needs checking inside the real approved frame once supplied. Core screenshots are developer previews, not finished deliverables.

## Required original artwork

The user asked, “remember the approved window?” It is the purple molded frame, real TYCO Kitchen Littles logo upper left, pink chef-hat badge centred, purple/white gingham trim, yellow inner border, and yellow minimize/close buttons. Its exact source image is unavailable among current workspace files and attachments. The assistant has asked the user to reattach it while continuing all independent work. Do not regenerate or invent a replacement frame. The user has not yet reattached it.

When the image arrives:

1. Inspect the exact source with `view_image`. Preserve its bytes as the frame, place the gameplay surface over its blank interior, and align transparent control hit areas to its existing buttons.
2. Write `frame-config.json` with `approved_original: true`, absolute source `path`, source `width` / `height`, measured percent rectangles `content`, `minimize`, `close`, and `drag`; optionally `preferredWidth` (the window should remain small, normally no larger than 640 pixels before fitting desktop bounds). Each rectangle uses `left`, `top`, `width`, `height` percentages.
3. Run `python build-program.py`, then `python integrate.py`. Production integration deliberately refuses to run without the exact frame config. No canonical HTML or ZIP has been modified yet.
4. Verify the real window, item scale, all foods, drawer interactions and preservation of existing independent programs. Run the meaningful checks against the actual integrated file; the earlier invisible fixture does not verify the frame artwork.
5. Follow `/workspace/github/RandomProjects/AGENTS.md`: rebuild the single-HTML ZIP, verify extracted bytes, commit and normal-push main, fetch the public SHA-pinned ZIP anonymously and verify it, then deliver that URL with the same-filename/local-folder replacement instructions.

## Files and commands

- `prepare-assets.py` creates `media/*.webp` and `ASSETS.json`; originals remain in place. Run it only when sprite mappings change.
- `build-program.py` embeds `PLAN.json`, the WebP atlas sheets, the gameplay code and desktop shell into `program-fragment.html`. It also creates a frameless private `harness.html` for core tests.
- `integrate.py` appends a uniquely marked independent block to the canonical app. It refuses duplicate blocks and verifies existing code remains byte-identical.
- The baseline canonical revision is recorded in `baseline.json`; current published commit was `ac9ac411c8edcc650315b1c4d3386be1b8a3a824` at task start.
- Space is tight. The disposable `integration-check.html` can be rebuilt from the current canonical source and fragment. Retired older development cache snapshots are byte-verified and recoverable from immutable Git history; recovery commands are in `retired-development-caches.json`. Never delete original user media, generated artwork or active program baselines to make space.
