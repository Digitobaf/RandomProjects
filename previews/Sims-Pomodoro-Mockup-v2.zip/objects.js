window.SIMS_OBJECTS = [
  {
    "id": "98e0f8bd",
    "name": "Poseidon's Adventure Aquarium",
    "label": "Aquarium",
    "defaultState": 0,
    "canvas": {
      "NE": {
        "width": 67,
        "height": 117,
        "anchorX": 34,
        "anchorY": 102
      },
      "SE": {
        "width": 67,
        "height": 117,
        "anchorX": 33,
        "anchorY": 102
      },
      "SW": {
        "width": 67,
        "height": 117,
        "anchorX": 34,
        "anchorY": 102
      },
      "NW": {
        "width": 67,
        "height": 117,
        "anchorX": 33,
        "anchorY": 102
      }
    },
    "pivots": {
      "NE": {
        "x": 33.5,
        "y": 58.5
      },
      "SE": {
        "x": 33.5,
        "y": 58.5
      },
      "SW": {
        "x": 33.5,
        "y": 58.5
      },
      "NW": {
        "x": 33.5,
        "y": 58.5
      }
    },
    "sprites": {
      "0": {
        "NE": "assets/images/a50140e364d0cce7a1614afb.png",
        "SE": "assets/images/b7d9b55fd6120bbace978724.png",
        "SW": "assets/images/a50140e364d0cce7a1614afb.png",
        "NW": "assets/images/b7d9b55fd6120bbace978724.png"
      },
      "1": {
        "NE": "assets/images/76f40af93813563c456eec43.png",
        "SE": "assets/images/30aa6d3086b2df8aa5b7a09b.png",
        "SW": "assets/images/76f40af93813563c456eec43.png",
        "NW": "assets/images/30aa6d3086b2df8aa5b7a09b.png"
      },
      "2": {
        "NE": "assets/images/22ecdcf13e05acacb173941d.png",
        "SE": "assets/images/17125c6d691f585a45e98035.png",
        "SW": "assets/images/22ecdcf13e05acacb173941d.png",
        "NW": "assets/images/17125c6d691f585a45e98035.png"
      },
      "3": {
        "NE": "assets/images/85df0a6c1acfed1bde756abc.png",
        "SE": "assets/images/ece1e57e7134b5803a59de45.png",
        "SW": "assets/images/85df0a6c1acfed1bde756abc.png",
        "NW": "assets/images/ece1e57e7134b5803a59de45.png"
      },
      "4": {
        "NE": "assets/images/2d4603b0248360b4a48039ec.png",
        "SE": "assets/images/e2e45d4f6550d78f87d7d479.png",
        "SW": "assets/images/2d4603b0248360b4a48039ec.png",
        "NW": "assets/images/e2e45d4f6550d78f87d7d479.png"
      },
      "5": {
        "NE": "assets/images/f364882fcb55e5f95ea6b45a.png",
        "SE": "assets/images/013fedd8de18a145076ed770.png",
        "SW": "assets/images/f364882fcb55e5f95ea6b45a.png",
        "NW": "assets/images/013fedd8de18a145076ed770.png"
      },
      "6": {
        "NE": "assets/images/32d46aa35d1f45d134a79d71.png",
        "SE": "assets/images/b2c9a8e4f24dbe4275a0d586.png",
        "SW": "assets/images/32d46aa35d1f45d134a79d71.png",
        "NW": "assets/images/b2c9a8e4f24dbe4275a0d586.png"
      },
      "7": {
        "NE": "assets/images/f9fdb16f87a88b114b3f8feb.png",
        "SE": "assets/images/f872b119f6182401235ba1cf.png",
        "SW": "assets/images/f9fdb16f87a88b114b3f8feb.png",
        "NW": "assets/images/f872b119f6182401235ba1cf.png"
      },
      "8": {
        "NE": "assets/images/172eb915f1ac0b7f499484e8.png",
        "SE": "assets/images/5dfe8e71a74a63e5b154dbf8.png",
        "SW": "assets/images/172eb915f1ac0b7f499484e8.png",
        "NW": "assets/images/5dfe8e71a74a63e5b154dbf8.png"
      },
      "9": {
        "NE": "assets/images/c10f8dc00328599478704c0c.png",
        "SE": "assets/images/c998719c560aa31e71c39974.png",
        "SW": "assets/images/c10f8dc00328599478704c0c.png",
        "NW": "assets/images/c998719c560aa31e71c39974.png"
      }
    },
    "sounds": {
      "aquarium_feed": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/71b06a6b71f09e04cef3bfdf.wav",
            "durationSec": 0.31
          },
          {
            "file": "assets/audio/1f78be096440e32f123cdf1f.wav",
            "durationSec": 0.41
          },
          {
            "file": "assets/audio/c812a540dbf765a61506fd4b.wav",
            "durationSec": 0.31
          },
          {
            "file": "assets/audio/9f49e2613309f88839e4afec.wav",
            "durationSec": 0.32
          },
          {
            "file": "assets/audio/b94ab498833fd4028c9408e3.wav",
            "durationSec": 0.34
          },
          {
            "file": "assets/audio/c7dff1d1b2a4a432cf0ee91d.wav",
            "durationSec": 0.33
          }
        ]
      },
      "aquarium_tapglass": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/d8d969df37a0c3ab5cd35ce8.wav",
            "durationSec": 0.22
          },
          {
            "file": "assets/audio/87c22accb79920df0c83297d.wav",
            "durationSec": 0.21
          },
          {
            "file": "assets/audio/5ef0df631f9a777bcfd39bc3.wav",
            "durationSec": 0.21
          },
          {
            "file": "assets/audio/66c108cc5483224a1d58953b.wav",
            "durationSec": 0.18
          },
          {
            "file": "assets/audio/485c9a813af310c3f7ff0cba.wav",
            "durationSec": 0.36
          }
        ]
      },
      "aquarium_running": {
        "loop": true,
        "clips": [
          {
            "file": "assets/audio/d0330660c3aaa812f3b0b9dd.wav",
            "durationSec": 2.91
          }
        ]
      }
    }
  },
  {
    "id": "a82ca08e",
    "name": "\"Fountain of Tranquility\"",
    "label": "Fountain",
    "defaultState": 0,
    "canvas": {
      "NE": {
        "width": 91,
        "height": 158,
        "anchorX": 46,
        "anchorY": 140
      },
      "SE": {
        "width": 91,
        "height": 158,
        "anchorX": 46,
        "anchorY": 140
      },
      "SW": {
        "width": 91,
        "height": 158,
        "anchorX": 46,
        "anchorY": 140
      },
      "NW": {
        "width": 91,
        "height": 158,
        "anchorX": 46,
        "anchorY": 140
      }
    },
    "pivots": {
      "NE": {
        "x": 45.5,
        "y": 79.0
      },
      "SE": {
        "x": 45.5,
        "y": 79.0
      },
      "SW": {
        "x": 45.5,
        "y": 79.0
      },
      "NW": {
        "x": 45.5,
        "y": 79.0
      }
    },
    "sprites": {
      "0": {
        "NE": "assets/images/a309dd6d4816bf54fe0de88f.png",
        "SE": "assets/images/a309dd6d4816bf54fe0de88f.png",
        "SW": "assets/images/a309dd6d4816bf54fe0de88f.png",
        "NW": "assets/images/a309dd6d4816bf54fe0de88f.png"
      },
      "1": {
        "NE": "assets/images/b2f26058a7f8896ced2f9f35.png",
        "SE": "assets/images/b2f26058a7f8896ced2f9f35.png",
        "SW": "assets/images/b2f26058a7f8896ced2f9f35.png",
        "NW": "assets/images/b2f26058a7f8896ced2f9f35.png"
      },
      "2": {
        "NE": "assets/images/a3fe58bce796d188ba84f79e.png",
        "SE": "assets/images/a3fe58bce796d188ba84f79e.png",
        "SW": "assets/images/a3fe58bce796d188ba84f79e.png",
        "NW": "assets/images/a3fe58bce796d188ba84f79e.png"
      },
      "3": {
        "NE": "assets/images/8181e6dfdb528c89a8aaa0ab.png",
        "SE": "assets/images/8181e6dfdb528c89a8aaa0ab.png",
        "SW": "assets/images/8181e6dfdb528c89a8aaa0ab.png",
        "NW": "assets/images/8181e6dfdb528c89a8aaa0ab.png"
      },
      "4": {
        "NE": "assets/images/2de72f82f765da051ca67ad5.png",
        "SE": "assets/images/2de72f82f765da051ca67ad5.png",
        "SW": "assets/images/2de72f82f765da051ca67ad5.png",
        "NW": "assets/images/2de72f82f765da051ca67ad5.png"
      }
    },
    "sounds": {
      "fountain_tinkle": {
        "loop": true,
        "clips": [
          {
            "file": "assets/audio/a73cbdd4ce345285b3f78394.wav",
            "durationSec": 3.98
          }
        ]
      }
    }
  },
  {
    "id": "8fed54c2",
    "name": "WhirlWizard Hot Tub",
    "label": "Hot Tub",
    "defaultState": 0,
    "canvas": {
      "NE": {
        "width": 224,
        "height": 183,
        "anchorX": 112,
        "anchorY": 99
      },
      "SE": {
        "width": 224,
        "height": 183,
        "anchorX": 176,
        "anchorY": 131
      },
      "SW": {
        "width": 224,
        "height": 183,
        "anchorX": 112,
        "anchorY": 163
      },
      "NW": {
        "width": 224,
        "height": 183,
        "anchorX": 48,
        "anchorY": 131
      }
    },
    "pivots": {
      "NE": {
        "x": 112.0,
        "y": 91.5
      },
      "SE": {
        "x": 112.0,
        "y": 91.5
      },
      "SW": {
        "x": 112.0,
        "y": 91.5
      },
      "NW": {
        "x": 112.0,
        "y": 91.5
      }
    },
    "sprites": {
      "0": {
        "NE": "assets/images/84cbb51249b5d9a38330d83f.png",
        "SE": "assets/images/84cbb51249b5d9a38330d83f.png",
        "SW": "assets/images/84cbb51249b5d9a38330d83f.png",
        "NW": "assets/images/84cbb51249b5d9a38330d83f.png"
      },
      "1": {
        "NE": "assets/images/db9b7922cb21482bee7b6573.png",
        "SE": "assets/images/db9b7922cb21482bee7b6573.png",
        "SW": "assets/images/db9b7922cb21482bee7b6573.png",
        "NW": "assets/images/db9b7922cb21482bee7b6573.png"
      },
      "2": {
        "NE": "assets/images/fe9bcd5d4da0a2e9e280d3c0.png",
        "SE": "assets/images/fe9bcd5d4da0a2e9e280d3c0.png",
        "SW": "assets/images/fe9bcd5d4da0a2e9e280d3c0.png",
        "NW": "assets/images/fe9bcd5d4da0a2e9e280d3c0.png"
      },
      "3": {
        "NE": "assets/images/902a729e0e68dd8f469c8afb.png",
        "SE": "assets/images/902a729e0e68dd8f469c8afb.png",
        "SW": "assets/images/902a729e0e68dd8f469c8afb.png",
        "NW": "assets/images/902a729e0e68dd8f469c8afb.png"
      }
    },
    "sounds": {
      "hottub_running": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/ce4a5f7b20dac708171913b6.wav",
            "durationSec": 3.99
          }
        ]
      }
    }
  },
  {
    "id": "bb626ef3",
    "name": "Positive Potential Microwave",
    "label": "Microwave",
    "defaultState": 0,
    "canvas": {
      "NE": {
        "width": 80,
        "height": 66,
        "anchorX": 42,
        "anchorY": 49
      },
      "SE": {
        "width": 69,
        "height": 68,
        "anchorX": 39,
        "anchorY": 55
      },
      "SW": {
        "width": 80,
        "height": 67,
        "anchorX": 38,
        "anchorY": 54
      },
      "NW": {
        "width": 69,
        "height": 70,
        "anchorX": 30,
        "anchorY": 51
      }
    },
    "pivots": {
      "NE": {
        "x": 34.5,
        "y": 33.0
      },
      "SE": {
        "x": 34.5,
        "y": 33.0
      },
      "SW": {
        "x": 45.5,
        "y": 33.5
      },
      "NW": {
        "x": 34.5,
        "y": 36.5
      }
    },
    "sprites": {
      "0": {
        "NE": "assets/images/2f4a3788cc2c68ac8cd6415f.png",
        "SE": "assets/images/dbcd6213b66b584491b14138.png",
        "SW": "assets/images/e083f5e3a01856b1a8120499.png",
        "NW": "assets/images/07ee7e0acd7cb2bac9f221aa.png"
      },
      "1": {
        "NE": "assets/images/38a8d811f6d4f21c58060861.png",
        "SE": "assets/images/0e2a02f6cbc772bbf84b7435.png",
        "SW": "assets/images/3f94d1f53ba63a5f484dcdf1.png",
        "NW": "assets/images/0651310ccd83804e658bc798.png"
      },
      "2": {
        "NE": "assets/images/db483b8100adec6713403fd5.png",
        "SE": "assets/images/d12e66eef38f4f12b1a31093.png",
        "SW": "assets/images/d596783a11af705a6caf0d37.png",
        "NW": "assets/images/7af798d64a89127ee7b9f221.png"
      },
      "3": {
        "NE": "assets/images/206c68b742f38c0b7e839926.png",
        "SE": "assets/images/e979e9657c62abb74c167c40.png",
        "SW": "assets/images/204957052fd30bebc37d5444.png",
        "NW": "assets/images/a91734a3c9c1af413bdb7c00.png"
      },
      "4": {
        "NE": "assets/images/2f2b816a8f51bd82000f04bb.png",
        "SE": "assets/images/964dda58a80da4ae0b3a4021.png",
        "SW": "assets/images/2e20a659007407d0355828d0.png",
        "NW": "assets/images/28119c322a7ab20a71389f15.png"
      },
      "5": {
        "NE": "assets/images/2f4a3788cc2c68ac8cd6415f.png",
        "SE": "assets/images/dbcd6213b66b584491b14138.png",
        "SW": "assets/images/e083f5e3a01856b1a8120499.png",
        "NW": "assets/images/07ee7e0acd7cb2bac9f221aa.png"
      }
    },
    "sounds": {
      "microwave_sopen": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/be357fb68a092ff3b9c3e5a5.wav",
            "durationSec": 0.35
          }
        ]
      },
      "microwave_sbeep": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/0db5cc848e48ca96deabf4db.wav",
            "durationSec": 0.16
          }
        ]
      },
      "microwave_scook": {
        "loop": true,
        "clips": [
          {
            "file": "assets/audio/6ef76dc2b6171cc81bc2870b.wav",
            "durationSec": 2
          }
        ]
      },
      "microwave_sdone": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/6a5338973972c494d0be236e.wav",
            "durationSec": 0.58
          }
        ]
      },
      "microwave_sclose": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/b187af56bd323aad4904e15f.wav",
            "durationSec": 0.57
          }
        ]
      }
    }
  },
  {
    "id": "543be3fe",
    "name": "Pizza Box",
    "label": "Pizza Box",
    "defaultState": 33,
    "canvas": {
      "NE": {
        "width": 57,
        "height": 45,
        "anchorX": 33,
        "anchorY": 34
      },
      "SE": {
        "width": 58,
        "height": 57,
        "anchorX": 34,
        "anchorY": 46
      },
      "SW": {
        "width": 58,
        "height": 57,
        "anchorX": 24,
        "anchorY": 46
      },
      "NW": {
        "width": 57,
        "height": 45,
        "anchorX": 24,
        "anchorY": 34
      }
    },
    "pivots": {
      "NE": {
        "x": 33.5,
        "y": 31.0
      },
      "SE": {
        "x": 34.5,
        "y": 43.5
      },
      "SW": {
        "x": 23.5,
        "y": 43.5
      },
      "NW": {
        "x": 23.5,
        "y": 31.0
      }
    },
    "sprites": {
      "33": {
        "NE": "assets/images/066e6f8170a93509b709be2e.png",
        "SE": "assets/images/97ca08360a4182f7fe41b130.png",
        "SW": "assets/images/809d24b8cbc030220b922ec5.png",
        "NW": "assets/images/5e53aa2496ed5faa946f598f.png"
      },
      "34": {
        "NE": "assets/images/15a350dd46f84d802097d8b9.png",
        "SE": "assets/images/a8651556455ffb99383a8273.png",
        "SW": "assets/images/ea99619a55317b1c5c92953b.png",
        "NW": "assets/images/db6a710d3a39a382fc4fa717.png"
      },
      "35": {
        "NE": "assets/images/2efafbaf96c34d9d8e29d485.png",
        "SE": "assets/images/c0f1c74728b35cc24b09676b.png",
        "SW": "assets/images/43be0da39a4832350377f40b.png",
        "NW": "assets/images/e73c7ae41da3e509dd774a75.png"
      }
    },
    "sounds": {
      "pizza_gooey": {
        "loop": false,
        "clips": [
          {
            "file": "assets/audio/057c7bddb0d50dfab989b683.wav",
            "durationSec": 0.17
          }
        ]
      }
    }
  }
];
