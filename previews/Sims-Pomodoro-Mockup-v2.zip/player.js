(()=>{
'use strict';
const root=document.querySelector('#sims-pomodoro-preview'),q=s=>root.querySelector(s),objects=window.SIMS_OBJECTS,behaviors=window.SIMS_BEHAVIORS,views=['NE','SE','SW','NW'];
const storageKey='sims-pomodoro-mockup:v2';
const defaults={objectId:objects[0].id,view:0,mode:'focus',focus:25,break:15,long:30,every:4,done:0,remaining:1500000,running:false,endAt:0,catalogOpen:true,settingsOpen:false,sound:true,volume:.5,sharp:false};
let state={...defaults},activity=null,interaction=null,lastDraw='',audioEpoch=0;
const playing=new Set(),imageMap=new Map();
function current(){return objects.find(o=>o.id===state.objectId)||objects[0];}
function behavior(){return behaviors[current().id];}
function duration(){return Math.round(state[state.mode]*60000);}
function remaining(){return state.running?Math.max(0,state.endAt-Date.now()):state.remaining;}
function announce(text){q('.sp-announcement').textContent=text;}
function persist(){try{localStorage.setItem(storageKey,JSON.stringify({...state,remaining:remaining(),running:false,endAt:0}));}catch{}}
try{
 const saved=JSON.parse(localStorage.getItem(storageKey)||'{}');
 for(const key of['focus','break','long'])if(Number.isFinite(saved[key])&&saved[key]>=.05&&saved[key]<=1440)state[key]=saved[key];
 if(objects.some(o=>o.id===saved.objectId))state.objectId=saved.objectId;
 if(Number.isInteger(saved.view))state.view=((saved.view%4)+4)%4;
 if(['focus','break','long'].includes(saved.mode))state.mode=saved.mode;
 for(const key of['catalogOpen','settingsOpen','sound','sharp'])if(typeof saved[key]==='boolean')state[key]=saved[key];
 if(Number.isFinite(saved.volume)&&saved.volume>=0&&saved.volume<=1)state.volume=saved.volume;
 if(Number.isInteger(saved.every)&&saved.every>=1&&saved.every<=12)state.every=saved.every;
 if(Number.isInteger(saved.done)&&saved.done>=0)state.done=saved.done;
 state.remaining=Number.isFinite(saved.remaining)&&saved.remaining>=0&&saved.remaining<=duration()?saved.remaining:duration();
}catch{}
for(const object of objects)for(const [graphic,sprites]of Object.entries(object.sprites))for(const [view,src]of Object.entries(sprites)){
 const image=new Image();image.src=src;imageMap.set(object.id+':'+graphic+':'+view,image);
 image.addEventListener('load',()=>{lastDraw='';draw();});
 image.addEventListener('error',()=>announce('An image is missing. Extract the entire ZIP, including assets.'));
}
function stopSounds(){audioEpoch++;for(const a of playing){a.pause();a.remove();}playing.clear();}
function playSound(event,{loopAllowed=true}={}){
 if(!event||!state.sound||document.hidden)return;
 const sound=current().sounds[event];if(!sound?.clips.length)return;
 const clip=sound.clips[Math.floor(Math.random()*sound.clips.length)];
 const a=new Audio(clip.file),epoch=audioEpoch;a.loop=loopAllowed&&sound.loop===true;a.volume=state.volume;a.hidden=true;a.dataset.event=event;root.append(a);playing.add(a);
 a.addEventListener('ended',()=>{playing.delete(a);a.remove();});
 const failed=()=>{if(playing.has(a)&&epoch===audioEpoch){playing.delete(a);a.remove();announce('Sound could not play. Check that the assets folder was extracted, then press Start again.');}};
 a.addEventListener('error',failed);a.play().catch(failed);
}
function startActivity(){
 stopSounds();interaction=null;activity={sequence:behavior().active,start:performance.now(),lastStep:-1};
 playSound(activity.sequence.sound);lastDraw='';
}
function stopActivity(){activity=null;interaction=null;stopSounds();lastDraw='';}
function frameAt(run,now){
 const seq=run.sequence,total=seq.steps.reduce((sum,s)=>sum+s.durationMs,0),elapsed=Math.max(0,now-run.start);
 if(!seq.loop&&elapsed>=total)return {step:seq.steps.at(-1),index:seq.steps.length-1,ended:true};
 let t=seq.loop?elapsed%total:elapsed,index=0;
 while(index<seq.steps.length-1&&t>=seq.steps[index].durationMs){t-=seq.steps[index].durationMs;index++;}
 return {step:seq.steps[index],index,ended:false};
}
function currentFrame(now){
 if(interaction){
  const f=frameAt(interaction,now);
  if(f.ended){interaction=null;stopSounds();lastDraw='';if(state.running){activity={sequence:behavior().active,start:now,lastStep:-1};playSound(activity.sequence.sound);}return currentFrame(now);}
  if(interaction.lastStep!==f.index){interaction.lastStep=f.index;playSound(interaction.sequence.stepSounds?.[f.index]);}
  return f.step;
 }
 if(activity&&state.running)return frameAt(activity,now).step;
 return {state:behavior().idle};
}
const canvas=q('.sp-canvas'),ctx=canvas.getContext('2d');
function extents(object){
 let left=Infinity,right=-Infinity,top=Infinity,bottom=-Infinity;
 for(const v of views){const c=object.canvas[v],p=object.pivots[v];left=Math.min(left,-p.x);right=Math.max(right,c.width-p.x);top=Math.min(top,-p.y);bottom=Math.max(bottom,c.height-p.y);}
 return {left,right,top,bottom};
}
function draw(force=false){
 const object=current(),view=views[state.view],now=performance.now(),frame=currentFrame(now),rect=canvas.getBoundingClientRect(),w=rect.width,h=rect.height,dpr=Math.min(2,devicePixelRatio||1);
 if(!w||!h)return;
 const key=[object.id,view,frame.state,frame.light,w,h,dpr,state.sharp].join(':');if(!force&&key===lastDraw)return;lastDraw=key;
 canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);ctx.imageSmoothingEnabled=!state.sharp;ctx.imageSmoothingQuality='high';canvas.style.imageRendering=state.sharp?'pixelated':'auto';
 const bounds=extents(object),scale=Math.min(2.4,(w-20)/(bounds.right-bounds.left),(h-12)/(bounds.bottom-bounds.top));
 const pivot=object.pivots[view],x=w/2-pivot.x*scale,y=h/2-pivot.y*scale,c=object.canvas[view],img=imageMap.get(object.id+':'+frame.state+':'+view);
 if(img?.complete&&img.naturalWidth)ctx.drawImage(img,x,y,c.width*scale,c.height*scale);
 if(frame.light){
  const light=behavior().light,polygon=light?.polygons[view];
  if(polygon){ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.beginPath();polygon.forEach(([px,py],i)=>i?ctx.lineTo(px,py):ctx.moveTo(px,py));ctx.closePath();ctx.globalCompositeOperation='screen';ctx.fillStyle=light.color;ctx.globalAlpha=.65;ctx.shadowColor=light.color;ctx.shadowBlur=5;ctx.fill();ctx.restore();}
 }
 canvas.dataset.graphic=String(frame.state);canvas.dataset.lit=String(!!frame.light);canvas.dataset.scale=String(scale);canvas.dataset.pivotX=String(x+pivot.x*scale);canvas.dataset.pivotY=String(y+pivot.y*scale);canvas.dataset.active=String(state.running);
 canvas.setAttribute('aria-label',object.name+', '+view+', '+(state.running?'active':'idle'));
}
function renderClock(){const seconds=Math.ceil(remaining()/1000);q('.sp-clock').textContent=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');}
function render(){
 const object=current();q('.sp-catalog').hidden=!state.catalogOpen;q('.sp-settings').hidden=!state.settingsOpen;root.classList.toggle('sp-catalog-hidden',!state.catalogOpen);
 q('.sp-buy').setAttribute('aria-expanded',String(state.catalogOpen));q('[data-action=settings]').setAttribute('aria-expanded',String(state.settingsOpen));q('.sp-disclosure-mark').textContent=state.settingsOpen?'▾':'▸';
 q('.sp-phase').value=state.mode;q('.sp-object-caption').textContent=object.label+'  '+views[state.view];q('.sp-selected-name').textContent=object.label;
 q('.sp-session').textContent='Session '+(state.done%state.every+1)+' of '+state.every;
 q('[data-action=start]').disabled=state.running;q('[data-action=start]').textContent=!state.running&&state.remaining<duration()?'Resume':'Start';q('[data-action=pause]').disabled=!state.running;
 q('.sp-sound-button').textContent='Sound: '+(state.sound?'on':'off');q('.sp-sound-button').setAttribute('aria-pressed',String(state.sound));
 for(const input of root.querySelectorAll('[data-duration]'))if(document.activeElement!==input)input.value=state[input.dataset.duration];
 q('.sp-cycles').value=state.every;q('.sp-sharp').checked=state.sharp;q('.sp-volume').value=state.volume;
 const bounds=extents(object);q('.sp-object').style.height=Math.min(330,Math.max(175,(bounds.bottom-bounds.top)*2.4+12))+'px';
 for(const b of root.querySelectorAll('.sp-tile'))b.setAttribute('aria-pressed',String(b.dataset.object===object.id));
 renderClock();draw(true);
}
function pause(message){state.remaining=remaining();state.running=false;state.endAt=0;stopActivity();render();announce(message);persist();}
function finish(){
 const event=behavior().finishedSound;stopActivity();
 if(state.mode==='focus'){state.done++;state.mode=state.done%state.every===0?'long':'break';}else state.mode='focus';
 state.running=false;state.endAt=0;state.remaining=duration();playSound(event);render();announce((state.mode==='focus'?'Focus':state.mode==='long'?'Long break':'Break')+' is ready. Press Start when ready.');persist();
}
function selectObject(id){state.objectId=id;stopActivity();if(state.running)startActivity();render();announce(current().label+' selected'+(state.running?' and running.':'. Press Start to activate it.'));persist();}
const catalog=q('.sp-catalog-grid');
for(const object of objects){const b=document.createElement('button');b.type='button';b.className='sp-tile';b.dataset.object=object.id;b.setAttribute('aria-label','Choose '+object.name);const img=document.createElement('img');img.src=object.sprites[String(object.defaultState)].NE;img.alt='';const name=document.createElement('span');name.textContent=object.label;b.append(img,name);b.addEventListener('click',()=>selectObject(object.id));catalog.append(b);}
root.addEventListener('click',e=>{
 const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;
 if(action==='left'||action==='right'){state.view=(state.view+(action==='left'?3:1))%4;render();}
 if(action==='catalog'){state.catalogOpen=!state.catalogOpen;render();}
 if(action==='settings'){state.settingsOpen=!state.settingsOpen;render();}
 if(action==='start'){if(state.remaining<=0)state.remaining=duration();state.endAt=Date.now()+state.remaining;state.running=true;startActivity();render();announce(current().label+' running.');}
 if(action==='pause')pause('Paused. Object activity stopped.');
 if(action==='reset'){state.running=false;state.endAt=0;state.remaining=duration();stopActivity();render();announce('Reset. Press Start to activate the object.');}
 if(action==='sound'){state.sound=!state.sound;stopSounds();if(state.running&&state.sound)playSound(interaction?interaction.sequence.sound:behavior().active.sound);render();}
 persist();
});
q('.sp-sprite-button').addEventListener('click',()=>{
 const seq=behavior().click;if(!seq){announce('Press Start for '+current().label.toLowerCase()+' activity.');return;}
 stopSounds();interaction={sequence:seq,start:performance.now(),lastStep:-1};playSound(seq.sound);lastDraw='';draw();
});
q('.sp-phase').addEventListener('change',e=>{pause('Timer phase changed.');state.mode=e.target.value;state.remaining=duration();render();persist();});
for(const input of root.querySelectorAll('[data-duration]'))input.addEventListener('change',()=>{
 const n=Number(input.value);if(!Number.isFinite(n)||n<.05||n>1440){q('.sp-error').textContent='Enter 0.05 to 1440 minutes.';q('.sp-error').hidden=false;return;}
 q('.sp-error').hidden=true;state[input.dataset.duration]=n;if(input.dataset.duration===state.mode){state.running=false;state.endAt=0;state.remaining=duration();stopActivity();}render();persist();
});
q('.sp-cycles').addEventListener('change',e=>{const n=Number(e.target.value);if(Number.isInteger(n)&&n>=1&&n<=12){state.every=n;persist();}render();});
q('.sp-sharp').addEventListener('change',e=>{state.sharp=e.target.checked;draw(true);persist();});
q('.sp-volume').addEventListener('input',e=>{state.volume=Number(e.target.value);for(const a of playing)a.volume=state.volume;persist();});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopSounds();else if(state.running){if(remaining()<=0)finish();else if(!interaction&&current().sounds[behavior().active.sound]?.loop)playSound(behavior().active.sound);}});
window.addEventListener('pagehide',()=>{persist();stopSounds();});
new ResizeObserver(()=>draw(true)).observe(q('.sp-object'));
render();
let lastSave=0;
setInterval(()=>{if(state.running&&remaining()<=0)finish();renderClock();draw();if(state.running&&Date.now()-lastSave>5000){lastSave=Date.now();persist();}},40);
})();
