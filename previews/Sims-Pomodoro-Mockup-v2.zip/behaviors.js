/* Editable prototype timings, not recovered game scripts. durationMs is milliseconds.
   active starts with the timer; click runs when the sprite is clicked.
   loop controls frames only. Sound loop flags come from objects.js.
   Non-looping sequences hold their last frame; click returns to active/idle.
   Microwave lighting is a provisional overlay; exported On aliases Closed. */
window.SIMS_BEHAVIORS = {
  "98e0f8bd": {
    "idle": 1,
    "active": {
      "steps": [
        {
          "state": 1,
          "durationMs": 230
        },
        {
          "state": 2,
          "durationMs": 230
        },
        {
          "state": 3,
          "durationMs": 230
        },
        {
          "state": 4,
          "durationMs": 230
        },
        {
          "state": 5,
          "durationMs": 230
        }
      ],
      "loop": true,
      "sound": "aquarium_running"
    },
    "click": {
      "steps": [
        {
          "state": 6,
          "durationMs": 230
        },
        {
          "state": 7,
          "durationMs": 230
        },
        {
          "state": 8,
          "durationMs": 230
        },
        {
          "state": 9,
          "durationMs": 230
        }
      ],
      "loop": false,
      "sound": "aquarium_feed"
    }
  },
  "a82ca08e": {
    "idle": 0,
    "active": {
      "steps": [
        {
          "state": 1,
          "durationMs": 200
        },
        {
          "state": 2,
          "durationMs": 200
        },
        {
          "state": 3,
          "durationMs": 200
        },
        {
          "state": 4,
          "durationMs": 200
        }
      ],
      "loop": true,
      "sound": "fountain_tinkle"
    }
  },
  "8fed54c2": {
    "idle": 0,
    "active": {
      "steps": [
        {
          "state": 1,
          "durationMs": 180
        },
        {
          "state": 2,
          "durationMs": 180
        },
        {
          "state": 3,
          "durationMs": 180
        }
      ],
      "loop": true,
      "sound": "hottub_running"
    }
  },
  "bb626ef3": {
    "idle": 0,
    "active": {
      "steps": [
        {
          "state": 5,
          "durationMs": 1200,
          "light": true
        }
      ],
      "loop": true,
      "sound": "microwave_scook"
    },
    "click": {
      "steps": [
        {
          "state": 1,
          "durationMs": 100
        },
        {
          "state": 2,
          "durationMs": 100
        },
        {
          "state": 3,
          "durationMs": 100
        },
        {
          "state": 4,
          "durationMs": 100
        },
        {
          "state": 4,
          "durationMs": 600
        },
        {
          "state": 3,
          "durationMs": 100
        },
        {
          "state": 2,
          "durationMs": 100
        },
        {
          "state": 1,
          "durationMs": 100
        },
        {
          "state": 0,
          "durationMs": 100
        }
      ],
      "loop": false,
      "sound": "microwave_sopen",
      "stepSounds": {
        "5": "microwave_sclose"
      }
    },
    "finishedSound": "microwave_sdone",
    "light": {
      "color": "#ffc969",
      "polygons": {
        "SE": [
          [
            33,
            39
          ],
          [
            50,
            30
          ],
          [
            50,
            43
          ],
          [
            33,
            53
          ]
        ],
        "SW": [
          [
            17,
            29
          ],
          [
            33,
            38
          ],
          [
            33,
            51
          ],
          [
            17,
            43
          ]
        ]
      }
    }
  },
  "543be3fe": {
    "idle": 33,
    "active": {
      "steps": [
        {
          "state": 33,
          "durationMs": 220
        },
        {
          "state": 34,
          "durationMs": 220
        },
        {
          "state": 35,
          "durationMs": 220
        }
      ],
      "loop": false,
      "sound": "pizza_gooey"
    },
    "click": {
      "steps": [
        {
          "state": 33,
          "durationMs": 200
        },
        {
          "state": 34,
          "durationMs": 200
        },
        {
          "state": 35,
          "durationMs": 200
        }
      ],
      "loop": false,
      "sound": "pizza_gooey"
    }
  }
};
