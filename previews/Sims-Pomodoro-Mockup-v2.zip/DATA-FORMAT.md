# Sims Pomodoro mockup v2 — handoff

This is a standalone working prototype, not a Casey's Room update. No Casey launcher, profiles, saves, origin or viewer files are changed.

## Files

- `Sims-Pomodoro-Mockup.html`: markup/styles; embedded fallback font only.
- `player.js`: generic timer, renderer and sound/sequence player.
- `objects.js`: declarative `window.SIMS_OBJECTS` array: GUID, sprites per graphic/view, canvas, source anchors, visual pivots, and sound events.
- `behaviors.js`: editable `window.SIMS_BEHAVIORS` object keyed by GUID. All object-specific sequences are here.
- `assets/images/<sha256-prefix>.png`: unchanged exported sprites and prototype control artwork.
- `assets/audio/<sha256-prefix>.wav`: original exported clips.
- `assets/manifest.json`: file checksums and the separate static AI test reference.

Classic JS data assignments allow Firefox to open the HTML directly without a local server or a file:// fetch restriction. Keep the assignment and trailing semicolon when editing the JSON-shaped data.

## Behavior fields

`idle` is the resting graphic number. `active` starts when the timer starts. `click`, if present, runs when the sprite is clicked, then returns to active or idle. A sequence contains:

```js
{
  "steps": [
    { "state": 1, "durationMs": 230 },
    { "state": 2, "durationMs": 230 }
  ],
  "loop": true,
  "sound": "aquarium_running"
}
```

`durationMs` must be a positive number of milliseconds. `loop` repeats graphics only; false holds the final active frame. A click sequence returns when its total duration ends. Optional `stepSounds` maps zero-based step indices to sound events. `finishedSound` plays at timer completion, not on Pause/Reset. All sound references resolve to that object's `sounds` in objects.js. Clips are selected randomly when an event has variants. Audio loop flags come from the original export, independently of frame loops. Hot-tub audio plays once on activation because the export explicitly says loop:false; do not silently convert it into an endless loop.

`light:true` uses that object's optional `light` definition: color and per-view polygon coordinates on the original sprite canvas. Only the microwave's front-facing SE/SW views have a window overlay. Its exported On state aliases Closed; the warm window light is a provisional runtime effect, not a recovered game layer.

## What remains provisional

All frame timings and click mappings are authored preview presets, not recovered Sims scripts. Fountain/hot-tub numbered runs are used here as proposed activity sequences and remain subject to Pollux's confirmation. Pizza opens and stays open; it does not invent an endless eating animation. The gooey clip's association with opening is provisional. Do not assume every event in an IFF belongs to the selected object.

The aquarium AI upscale is a static empty-tank test only, listed in assets/manifest.json. It is not used in the animation. Original animated frames remain unchanged; a matching full frame set needs review before replacing them.

## Alignment and persistence

Each view uses a fixed pivot from the default-state visible bounding box. The pivot is shared by every frame within that view. Scale stays consistent across views and is capped at 2.4 times native CSS pixels. This prevents the hot tub orbiting around tile-zero anchors while preserving those game anchors as metadata.

Only this mockup uses localStorage key `sims-pomodoro-mockup:v2`. The live countdown uses an absolute wall-clock end time. Reload restores paused. No Casey's Room storage keys are accessed. Assets have hash-derived filenames and are never edited in place; new artwork needs a new hash and reference.
