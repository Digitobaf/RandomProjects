TamaScape — skin and control prototype

Open TamaScape.html locally in a modern browser. Its artwork is embedded, so the HTML can be used on its own.

Left button: switch between Blue glitter, Lime apple, and Strawberry.
Middle button: Office, Café, Train, Beach, then back to Office.
Right button: hover and scroll up/down to change volume. Keyboard arrows also work when this control is focused.

Every skin PNG has the same 1536 x 1710 transparent canvas. Every screen opening is exactly 512 x 512, at x=512, y=660, with matching rounded corners. screen-layout.json contains the shared screen rectangle and each skin's physical button positions.

Office, Café, Train, and Beach currently have named scene slots. No scene artwork or ambience recordings are bundled yet. The player is wired for one looping track per scene; skin changes keep the same scene and volume.

skins/ contains the normalized transparent PNGs.
