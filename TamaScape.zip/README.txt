TamaScape

Unzip this download and open TamaScape.html in a modern browser. All artwork, animation, and audio are embedded, so the HTML also works on its own without an internet connection.

Left button: switch between Blue glitter, Lime apple, and Strawberry.
Middle button: Office, Café, Train, Beach, then back to Office.
Right button: hover and scroll up/down to change volume; no click is required. Keyboard arrows also work when this control is focused.

Office: tiny alternating taps using the original hands.
Café: a one-pixel breathing idle and occasional pixel steam; the cup stays still.
Train: a small stepped cabin rattle and scrolling scenery outside the window.
Beach: a few stepped shoreline positions; Kuchipatchi stays still.

The supplied office and café recordings loop unchanged. Train and beach have no ambience tracks yet. The supplied opening, skin-switch, and scene-switch effects have their leading/trailing dead air removed, with their sound tails preserved. Some browsers require a first interaction before allowing sound. Volume controls both ambience and interface sounds.

Skin changes preserve the current scene, animation phase, audio playback, and volume. Preferences are saved locally when the browser permits it. Animation pauses in hidden tabs and respects the system's reduced-motion setting.

Every skin PNG has the same 1536 x 1710 transparent canvas. Every screen opening is exactly 512 x 512, at x=512, y=660, with matching rounded corners. The blue skin keeps its oval metal ring; its beaded chain is removed.

Reusable assets:
- skins/: normalized transparent skin PNGs.
- media/scenes/: lossless copies of the supplied scene artwork, plus small-use animation background plates.
- media/interface/: trimmed interface sounds.
- media/ambience/: the supplied office/café MP3 recordings, unchanged.
- screen-layout.json: shared screen rectangle, button positions, and media mapping.
- interface-trim-report.json: source and trimmed durations.
